-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 25, 2011 at 10:43 AM
-- Server version: 5.1.40
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kupontut`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `position` mediumint(5) NOT NULL DEFAULT '0',
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text NOT NULL,
  `url` varchar(300) NOT NULL,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `fetch_pages` text NOT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `tpl` varchar(50) DEFAULT NULL,
  `page_tpl` varchar(50) DEFAULT NULL,
  `per_page` smallint(5) NOT NULL,
  `order_by` varchar(25) NOT NULL,
  `sort_order` varchar(25) NOT NULL,
  `comments_default` tinyint(1) NOT NULL DEFAULT '0',
  `field_group` int(11) NOT NULL,
  `category_field_group` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`) VALUES
(1, 0, 0, 'Главная', '', '', 'main', '', '', '', 'b:0;', '', '', '', 10, 'publish_date', 'desc', 1, 0, 0),
(56, 0, 0, 'Новости и акции', '', '', 'news', '', '', '', 'b:0;', 'main', 'category_text', 'page_full_text', 15, 'publish_date', 'desc', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `category_translate`
--

CREATE TABLE IF NOT EXISTS `category_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `lang` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category_translate`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(25) NOT NULL DEFAULT 'core',
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_mail` varchar(50) NOT NULL,
  `user_site` varchar(250) NOT NULL,
  `item_id` bigint(11) NOT NULL,
  `text` varchar(500) NOT NULL,
  `date` int(11) NOT NULL,
  `status` smallint(1) NOT NULL,
  `agent` varchar(250) NOT NULL,
  `user_ip` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `item_id` (`item_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `module`, `user_id`, `user_name`, `user_mail`, `user_site`, `item_id`, `text`, `date`, `status`, `agent`, `user_ip`) VALUES
(10, 'core', 1, 'admin', 'admin@localhost.loc', '', 32, 'Первый комментарий.', 1267280509, 0, 'Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/532.8 (KHTML, like Gecko) Chrome/4.0.302.2 Safari/532.8', '127.0.0.5');

-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE IF NOT EXISTS `components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `identif` varchar(25) NOT NULL,
  `enabled` int(1) NOT NULL,
  `autoload` int(1) NOT NULL,
  `in_menu` int(1) NOT NULL DEFAULT '0',
  `settings` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `identif` (`identif`),
  KEY `enabled` (`enabled`),
  KEY `autoload` (`autoload`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=122 ;

--
-- Dumping data for table `components`
--

INSERT INTO `components` (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`) VALUES
(1, 'user_manager', 'user_manager', 1, 1, 0, NULL),
(2, 'auth', 'auth', 1, 0, 0, NULL),
(4, 'comments', 'comments', 1, 1, 1, 'a:5:{s:18:"max_comment_length";i:550;s:6:"period";i:0;s:11:"can_comment";i:0;s:11:"use_captcha";b:1;s:14:"use_moderation";b:0;}'),
(7, 'navigation', 'navigation', 0, 0, 1, NULL),
(30, 'tags', 'tags', 1, 1, 1, NULL),
(92, 'gallery', 'gallery', 1, 0, 1, 'a:26:{s:13:"max_file_size";s:1:"5";s:9:"max_width";s:1:"0";s:10:"max_height";s:1:"0";s:7:"quality";s:2:"95";s:14:"maintain_ratio";b:1;s:19:"maintain_ratio_prev";b:1;s:19:"maintain_ratio_icon";b:1;s:4:"crop";b:0;s:9:"crop_prev";b:0;s:9:"crop_icon";b:0;s:14:"prev_img_width";s:3:"500";s:15:"prev_img_height";s:3:"500";s:11:"thumb_width";s:3:"100";s:12:"thumb_height";s:3:"100";s:14:"watermark_text";s:0:"";s:16:"wm_vrt_alignment";s:6:"bottom";s:16:"wm_hor_alignment";s:4:"left";s:19:"watermark_font_size";s:2:"14";s:15:"watermark_color";s:6:"ffffff";s:17:"watermark_padding";s:2:"-5";s:19:"watermark_font_path";s:20:"./system/fonts/1.ttf";s:15:"watermark_image";s:0:"";s:23:"watermark_image_opacity";s:2:"50";s:14:"watermark_type";s:4:"text";s:8:"order_by";s:4:"date";s:10:"sort_order";s:4:"desc";}'),
(55, 'rss', 'rss', 1, 0, 1, 'a:5:{s:5:"title";s:9:"Image CMS";s:11:"description";s:35:"Тестируем модуль RSS";s:10:"categories";a:1:{i:0;s:1:"3";}s:9:"cache_ttl";i:60;s:11:"pages_count";i:10;}'),
(72, 'imagebox', 'imagebox', 0, 1, 0, 'a:6:{s:9:"max_width";i:800;s:10:"max_height";i:600;s:11:"thumb_width";i:100;s:12:"thumb_height";i:100;s:14:"maintain_ratio";b:1;s:7:"quality";s:3:"95%";}'),
(60, 'menu', 'menu', 0, 1, 1, NULL),
(58, 'sitemap', 'sitemap', 1, 0, 1, 'a:5:{s:18:"main_page_priority";s:1:"1";s:13:"cats_priority";s:3:"0.9";s:14:"pages_priority";s:3:"0.5";s:20:"main_page_changefreq";s:6:"weekly";s:16:"pages_changefreq";s:7:"monthly";}'),
(80, 'search', 'search', 1, 0, 0, NULL),
(84, 'feedback', 'feedback', 1, 0, 0, 'a:2:{s:5:"email";s:19:"admin@localhost.loc";s:15:"message_max_len";i:550;}'),
(117, 'template_editor', 'template_editor', 0, 0, 0, NULL),
(86, 'group_mailer', 'group_mailer', 0, 0, 1, NULL),
(95, 'filter', 'filter', 1, 0, 0, NULL),
(96, 'cfcm', 'cfcm', 0, 0, 0, NULL),
(121, 'shop', 'shop', 1, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `meta_title` varchar(300) DEFAULT NULL,
  `url` varchar(500) NOT NULL,
  `cat_url` varchar(260) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `prev_text` text,
  `full_text` longtext NOT NULL,
  `category` int(11) NOT NULL,
  `full_tpl` varchar(50) DEFAULT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `position` smallint(5) NOT NULL,
  `comments_status` smallint(1) NOT NULL,
  `comments_count` int(9) DEFAULT '0',
  `post_status` varchar(15) NOT NULL,
  `author` varchar(50) NOT NULL,
  `publish_date` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `showed` int(11) NOT NULL,
  `lang` int(11) NOT NULL DEFAULT '0',
  `lang_alias` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `url` (`url`(333)),
  KEY `lang` (`lang`),
  KEY `post_status` (`post_status`(4)),
  KEY `cat_url` (`cat_url`),
  KEY `publish_date` (`publish_date`),
  KEY `category` (`category`),
  KEY `created` (`created`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES
(69, 'Спешите приобрести свой GPS', '', 'speshite_priobresti_svoi_gps', 'news/', 'рамках, акции, потеряйся, пустыне, gps, установлена, специальная, цена', 'В рамках акции не потеряйся в пустыне на все GPS установлена специальная цена.', '<p>В рамках акции "не потеряйся в пустыне" на все GPS установлена специальная цена.</p>', '', 56, '', '', 0, 0, 0, 'publish', 'admin', 1291632619, 1291632635, 1291982906, 27, 3, 0),
(35, 'О сайте', '', 'o-sajte', '', 'это, базовый, шаблон, imagecms, котором, релизованы, следующие, функции, вывод, фотогалереи, статической, статьи, блога', 'Это базовый шаблон ImageCMS, на котором релизованы следующие функции: вывод фотогалереи, вывод статической статьи, вывод блога.', '<p>Это базовый шаблон ImageCMS, на котором релизованы следующие функции: отображение фотогалереи, отображение статической статьи, отображение корпоративного блога, отображение формы обратной связи.</p>\n<p>Общий вид шаблона можно отредактировать и изменить лого, графическую вставку на свои тематические.</p>\n<p>Слева в сайдбаре Вы видите список категорий блога, который легко вставляется с помощью функции {sub_category_list()} в файле main.tpl. Также в левом сайдбаре находится форма поиска по сайту, виджет последних комментариев и виджет тегов сайта. В этот сайдбар можно также добавить виджет последних либо популярных новостей, а также любые счетчики, информеры.</p>\n<p>Верхнее меню реализовано с помощью модуля Меню. Управлять его содержимым можно из административной части в разделе Меню - Главное меню. Сюда как правило можно еще добавить страницы: о компании, контакты, услуги и т.п.</p>\n<p>За дополнительной информацией обращайтесь в официальный раздел документации: <a href="http://www.imagecms.net/wiki">http://www.imagecms.net/wiki</a></p>\n<p>Обсудить дополнительные возможности, а также вопросы по установке, настройке системы можно на официальном форуме: <a href="http://forum.imagecms.net/index.php">http://forum.imagecms.net/</a></p>', '', 0, 'page_static', '', 0, 1, 0, 'publish', 'admin', 1267203253, 1267203328, 1290100400, 8, 3, 0),
(64, 'О магазине', '', 'about', '', 'магазине', 'О магазине', '<p>Магазин ImageCMS Shop предоставляет огромный выбор техники на любой вкус по лучшим ценам.</p>\n<p>Наш магазин существует более 5 лет и за это время не было ни единого возврата товара.</p>\n<p>Мы обслуживаем ежедневно сотни покупателей и делаем это с радостью.</p>\n<p><strong>Покупайте технику у нас и становитесь обладателем лучшей в мире техники!!!</strong></p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295776, 1291295792, 1291743386, 233, 3, 0),
(65, 'Оплата', '', 'pay', '', 'оплата', 'Оплата', '<div class="pays">\n<h2>Выберите способ оплаты</h2>\n<p><a href="#"><img src="/templates/kupon/images/pay1.png" alt="" /></a> <a href="#"><img src="/templates/kupon/images/pay2.png" alt="" /></a> <a href="#"><img src="/templates/kupon/images/pay3.png" alt="" /></a> <a href="#"><img src="/templates/kupon/images/pay4.png" alt="" /></a> <a href="#"><img src="/templates/kupon/images/pay5.png" alt="" /></a> <a href="#"><img src="/templates/kupon/images/pay6.png" alt="" /></a></p>\n<label><input name="ch" type="checkbox" value="1" /><span>При покупке купона Вы соглашаетесь с договором публичной <a href="#">оферты</a></span></label></div>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295824, 1291295836, 1310994059, 129, 3, 0),
(66, 'Доставка', '', 'dostavka', '', 'доставка', 'Доставка', '<p>Мы поддерживаем доставку службой Автомир по всему миру.</p>\n<p>Также возможна доставка курьером для всех больших городов Украины и России (возможность доставки курьером в Вашем городе уточняйте по телефону <strong>0 800 820 22 22</strong>).</p>\n<p>При желании Вы можете сами забрать купленный товар в наших офисах.</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295844, 1291295851, 1291743683, 95, 3, 0),
(67, 'Помощь', '', 'help', '', 'помощь', 'Помощь', '<p>Для того, чтобы приобрести товар в нашем магазине, Вам нужно выполнить несколько простых шагов:</p>\n<ul>\n<li>Выбрать нужный товар, воспользовавшить навигацией слева, либо поиском.</li>\n<li>Добавить товар в корзину.</li>\n<li>Перейти в корзину, выбрать способ доставки и указать Ваши контактные данные.</li>\n<li>Подтвердить заказ и выбрать способ оплаты.</li>\n</ul>\n<p>После этого наши менеджеры свяжуться с Вами и помогут с оплатой и доставкой товара, а также проконсультируют по любому вопросу.</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295855, 1291295867, 1291743919, 49, 3, 0),
(68, 'Контакты', '', 'contact_us', '', 'контакты', 'Контакты', '<p><strong>Горячий телефон</strong>: 0 800 80 80 800</p>\n<p><strong>Главный офис в Москве</strong></p>\n<p>ул. Гагарина 1/2</p>\n<p>тел. 095 095 00 00</p>\n<p>&nbsp;</p>\n<p><strong>Главный офис в Киеве</strong></p>\n<p>ул. Гагарина 1/2</p>\n<p>тел. 098 098 00 00</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295870, 1291295888, 1291744068, 50, 3, 0),
(72, 'Как это работает', '', 'kak-eto-rabotaet', '', 'выбирай, акцию, регулярно, получайте, всевозможные, предложения, ресторанов, салонов, красоты, кинотеатров, скидкой, менее, ndash, вашем, городе, оплати, любым, способом, нажмите, кнопку, купить, купон, выберите, удобный, способ, оплаты, через, отделение, банка, пластиковой', '1 Выбирай акцию Регулярно получайте всевозможные предложения от ресторанов, салонов красоты, кинотеатров со скидкой не менее 50 &ndash 90% в вашем городе.     2 Оплати любым способом Нажмите на кнопку Купить купон. Выберите удобный способ оплаты: через', '<div class="crumb"><span>Как это работает</span><a href="/voprosy-i-podderzhka">Вопросы и поддержка</a></div>\n<ul class="how_it">\n<li> <img src="/templates/kupon/images/h1.gif" alt="" />\n<div class="how1"><span>1</span>\n<h1>Выбирай акцию</h1>\n<p>Регулярно получайте всевозможные предложения от ресторанов, салонов красоты, кинотеатров со скидкой не менее 50 &ndash; 90% в вашем городе.</p>\n</div>\n</li>\n<li> <img src="/templates/kupon/images/h2.png" alt="" />\n<div class="how2"><span>2</span>\n<h1>Оплати любым способом</h1>\n<p>Нажмите на кнопку &laquo;Купить купон&raquo;. Выберите удобный способ оплаты: через отделение банка, пластиковой картой, система Ipay, EasyPay или WebMoney.</p>\n</div>\n</li>\n<li> <img src="/templates/kupon/images/h3.gif" alt="" />\n<div class="how3"><span>3</span>\n<h1>Используй свой купон</h1>\n<p>Получите скидку, предъявив распечатанный купон или назвав его номер в заведении в течение срока проведения акции.</p>\n</div>\n</li>\n</ul>', '', 0, 'no_title', '', 0, 1, 0, 'publish', 'admin', 1310982016, 1310982016, 1310995625, 22, 3, 0),
(73, 'Вопросы и поддержка', '', 'voprosy-i-podderzhka', '', 'такое, kupontut, уникальные, предложения, разных, услуг, выгодной, цене, скидкой, также, акции, продаже, товаров, использовать, купон, могу, подарить, свой, другому, человеку', 'Что такое KuponTut.by ? Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%,а также акции по продаже товаров со скидкой от 25 до 90%.  Как использовать купон ? Это уникальные предложения разных  услуг  по выгодной цене со с', '<div class="crumb"><span>Вопросы и поддержка</span><a href="/kak-eto-rabotaet">Как это работает</a></div>\n<ol class="faq_list">\n<li><a href="#">Что такое KuponTut.by ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%,<br />а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Могу я подарить свой купон другому человеку ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Что такое KuponTut.by ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Могу я подарить свой купон другому человеку ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Могу я подарить свой купон другому человеку ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Как использовать купон ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n<li><a href="#">Могу я подарить свой купон другому человеку ?</a>\n<p>Это уникальные предложения разных  услуг  по выгодной цене со скидкой от 50 до 90%, а также акции по продаже товаров со скидкой от 25 до 90%.</p>\n</li>\n</ol>', '', 0, 'no_title', '', 0, 1, 0, 'publish', 'admin', 1310982139, 1310982139, 1310995601, 35, 3, 0),
(74, 'Новая игровая зона в Rubin Plaza', '', 'novaia-igrovaia-zona-v-rubin-plaza', 'news/', 'для, того, чтобы, добиться, чего, жизни, нужно, обладать, определенными, качествами, однако, нас, силу, воспитания, других, факторов, наделены, прямолинейностью, целенаправленностью, уверенностью, себе, оптимизмом, hellip, снимите, стресс, избавьтесь, переутомления, восстановите, гармонию, своего', 'Для того чтобы добиться чего-то в жизни, нужно обладать определенными качествами. Однако не все из нас в силу воспитания или других факторов наделены прямолинейностью, целенаправленностью, уверенностью в себе, оптимизмом&hellip  Для того чтобы добиться че', '<p>Для того чтобы добиться чего-то в жизни, нужно обладать определенными качествами. Однако не все из нас в силу воспитания или других факторов наделены прямолинейностью, целенаправленностью, уверенностью в себе, оптимизмом&hellip;</p>\n<div class="photo"><span><img src="/templates/kupon/images/4.jpg" alt="" /></span>\n<p>Для того чтобы добиться чего-то в жизни,<br />нужно обладать определенными качествами.</p>\n</div>\n<p>Снимите стресс и избавьтесь от переутомления, восстановите гармонию своего тела и разума, получите мощный заряд энергии и незабываемые впечатления, подарите себе наслаждение.</p>\n<p>Не забудьте и про подарочные сертификаты спа, которые могут стать великолепным подарком для ваших близких. Подарки всегда было очень сложно выбирать, но так было до тех пор, пока у нас не появились подарочные сертификаты spa.</p>\n<p>Можно ошибиться с выбором парфюма, можно не угадать с цветом, размером, вкусом, но с подарочными сертификатами spa ошибиться нельзя. Это именно тот универсальный подарок, который будет одинаково приятен и близкому человеку, и деловому партнеру и даже боссу. Ведь подарочные сертификаты спа &mdash; это отличное настроение, отдых и здоровье в одном флаконе. Это то, что невозможно измерить никакими деньгами!</p>\n<ul>\n<li>Стильное, бескаркасное кресло, на котором удобно сидеть</li>\n<li>Оригинальный подарок на любой праздник себе и близким</li>\n<li>Принимает форму тела, подстраивается под Вашу спину</li>\n</ul>\n<p>Салон красоты дружно соседствует с шикарным сирийско-ливанским рестораном, где будет приятно провести время с друзьями, покоряя всех неотразимой внешностью, отточенной заботливыми руками специалистов нашего салона.</p>\n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr class="title">\n<td>Программа</td>\n<td>Возраст</td>\n<td>Стоимость</td>\n</tr>\n<tr>\n<td>Apha Planet Zoom</td>\n<td>от  10 лет</td>\n<td>20 000 руб.</td>\n</tr>\n<tr class="next">\n<td>Apha Planet Zoom</td>\n<td>от  10 лет</td>\n<td>20 000 руб.</td>\n</tr>\n<tr>\n<td>Apha Planet Zoom</td>\n<td>от  10 лет</td>\n<td>20 000 руб.</td>\n</tr>\n<tr class="next">\n<td>Apha Planet Zoom</td>\n<td>от  10 лет</td>\n<td>20 000 руб.</td>\n</tr>\n</tbody>\n</table>\n<p>SPA -процедуры направлены на оздоровление и релаксацию всего организма в целом. Воздействуя через кожный покров, SPA-компоненты активизируют процессы объмена веществ, улучшают кровообращение, выводят токсины и шлаки из организма и улучшают общее самочувствие. После процедур кожа становится необыкновенно мягкая и упругая, приобретает тонус и насыщается жизненной энергией.</p>', '', 56, '', '', 0, 1, 0, 'publish', 'admin', 1310990675, 1310990675, 1310991143, 5, 3, 0),
(75, 'Поставщикам', '', 'distributor', '', 'вам, нужны, новые, клиенты, приведем, почему, выгодно, работать, нами, гарантировано, придут, предложениями, нашего, сайта, можно, воспользоваться, только, при, условии, куплено, минимальное, количество, купонов, гарантируем, лояльных, клиентов, которые, купят, купон, большинстве', 'Вам нужны новые клиенты? Мы приведем их к вам! Почему выгодно работать с нами? К вам гарантировано придут новые клиенты Предложениями  нашего сайта можно воспользоваться только при условии, что куплено  минимальное количество купонов. И мы гарантируем вам', '<p>Вам нужны новые клиенты? Мы приведем их к вам!</p>\n<h2>Почему выгодно работать с нами?</h2>\n<h3>К вам гарантировано придут новые клиенты</h3>\n<p>Предложениями  нашего сайта можно воспользоваться только при условии, что куплено  минимальное количество купонов. И мы гарантируем вам это минимальное  количество лояльных клиентов, которые не только купят купон, но и в  большинстве случаев потратят у вас на 60% больше стоимости купона.</p>\n<h3>Вы получаете эффективную рекламную кампанию бесплатно</h3>\n<p>Мы  зарабатываем % от продаж ваших услуг на нашем сайте. Вы ничего не  тратите, получая при этом масштабную вирусную рекламную кампанию, эффект  от которой можно будет легко измерить и оценить.</p>\n<h3>Ваше предложение будет уникальным и эксклюзивным</h3>\n<p>Во  время вашей акции на сайте Выгода.ru можно будет приобрести только это  уникальное предложение. Все внимание нашей аудитории будет сосредоточено  на вашей компании, услугах и конкретном предложении.</p>\n<h3>Вирусный эффект от акции будет работать и после ее окончания</h3>\n<p>Мы  расскажем о вашем предложении не только на сайте, но и во всех самых  популярных социальных сетях, где так быстро и легко действительно  хорошие предложения получают огромный отклик. Наши пользователи в сетях  Вконтакте, Facebook, ЖЖ и Twitter будут рассказывать друзьям о вашей  услуге как во время акции, так и после ее окончания.</p>\n<p><br />Чтобы начать сотрудничество, просто свяжитесь с нами.</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1310991213, 1310991213, 0, 3, 3, 0),
(76, 'Способы оплаты', '', 'payment_methods', '', 'webpay, пластиковая, карта, банковские, карточки, visa, mastercard, через, систему, электронных, платежей, важно, возможностях, оплаты, вашей, картой, интернет, можете, узнать, своем, банке, необходимо, выполнить, следующие, действия, выбрать, метод, ввести, появившейся, форме', 'WebPay (пластиковая карта) Банковские карточки VISA и MasterCard (через систему электронных платежей WEBPAY)Важно! О возможностях оплаты Вашей картой в Интернет Вы можете узнать в своем банке.   Необходимо выполнить следующие действия:Выбрать метод о', '<table border="0">\n<tbody>\n<tr>\n<td><img src="http://bongo.by/images/webpay.jpg" alt="WebPay" /></td>\n<td valign="top">\n<h3><a href="http://www.webpay.by/" target="_blank">WebPay (пластиковая карта)</a></h3>\n<span>Банковские карточки VISA и MasterCard (через систему электронных платежей WEBPAY);<br /><strong>Важно! О возможностях оплаты Вашей картой в Интернет Вы можете узнать в своем банке.</strong></span> <br /> <br /> <span>Необходимо выполнить следующие действия:<br />Выбрать метод оплаты WEBPAY; <br />Ввести в появившейся форме реквизиты своей пластиковой карточки; <br />Нажать "Оплатить"; <br />Нажать "Завершить платеж".</span></td>\n</tr>\n</tbody>\n</table>\n<div>\n<table border="0">\n<tbody>\n<tr>\n<td><img src="http://bongo.by/images/cash.jpg" alt="Наличные" /></td>\n<td valign="top">\n<h3><a href="http://bongo.by/info/payment">Наличные с лицевого счета</a></h3>\n<span>Наличные платежи в отделениях ОАО "АСБ "Беларусбанк" г.Минска;</span> <br /> <br /> <span> Необходимо выполнить следующие действия:<br /> Выбрать метод оплаты &laquo;Наличные с лицевого счета&raquo;;<br /> Если у вас достаточно средств на лицевом счету, то вы увидите окошко,  которое предупредит вас о том, что деньги будут списаны с лицевого  счета. Нажав &laquo;подтвердить&raquo;, вы произведете покупку;<br /> Если на лицевом счету средств недостаточно, то система сформирует заявку на покупку купона;<br /> Как только нужная сумма поступит на лицевой счет, заявка автоматически обработается, и вы получите уведомление на свой e-mail.<br /><br /> <strong>Чтобы пополнить лицевой счет необходимо:</strong><br /> <strong>Важно! пополнить лицевой счет можно только в отделениях ОАО "АСБ "Беларусбанк" г.Минска.</strong><br /> Зайти в свой профиль, нажав &laquo;Мои купоны&raquo;;<br /> Выбрать пункт меню &laquo;Лицевой счет&raquo;;<br /> Нажать на кнопку &laquo;Пополнить&raquo; и распечатать либо переписать реквизиты  дописав недостающие данные (напр. адрес, сумма). Важно! никакие другие  реквизиты кроме тех что указаны при нажатии на кнопку "Пополнить"  указывать не надо (напр. УНП или код банка);<br /> Сделать платеж в любом отделении <strong>ОАО "АСБ "Беларусбанк" г.Минска</strong>;<br /> В течение часа перечисленная сумма поступит на баланс вашего лицевого счета. </span></td>\n</tr>\n</tbody>\n</table>\n</div>\n<div>\n<table border="0">\n<tbody>\n<tr>\n<td><img src="http://bongo.by/images/easypay.jpg" alt="EasyPay" /></td>\n<td valign="top">\n<h3><a href="http://www.easypay.by/" target="_blank">EasyPay</a></h3>\n<span>Система Интернет-платежей EasyPay (эмитент электронных денег EasyPay - ОАО "Белгазпромбанк");</span> <br /> <br /> <span>Необходимо выполнить следующие действия:<br />Выбрать метод оплаты EasyPay; <br />Указать номер своего электронного кошелька; <br />Нажать "Выставить счет"; <br />Подтвердить оплату с помощью инструмента управления своим кошельком.</span></td>\n</tr>\n</tbody>\n</table>\n</div>\n<div>\n<table border="0">\n<tbody>\n<tr>\n<td><img src="http://bongo.by/images/webmoney.jpg" alt="WebMoney" /></td>\n<td valign="top">\n<h3><a href="http://www.wmtransfer.by/" target="_blank">WebMoney</a></h3>\n<span>Система онлайн-платежей  WebMoney в валюте WMB (эл. эквивалент белорусского рубля - национальной  валюты Республики Беларусь, гарантом WMB в Республике Беларусь является  ОАО "Технобанк").</span> <br /> <br /> <span>Необходимо выполнить следующие действия:<br />Выбрать метод оплаты WebMoney; <br />Пройти авторизацию системы Merchant; <br />Нажать "Оплатить".</span></td>\n</tr>\n</tbody>\n</table>\n</div>\n<table border="0">\n<tbody>\n<tr>\n<td><img src="http://bongo.by/images/ipay.jpg" alt="iPay" /></td>\n<td valign="top">\n<h3><a href="http://www.ipay.by/" target="_blank">iPay (со счета МТС)</a></h3>\n<span>Система платежей iPay (эмитент  электронных денег iPay - ОАО "Паритетбанк"). С системой iPay абоненты  МТС могут оплачивать различные услуги, не выходя из дома, используя  средства на своем лицевом счете МТС.</span> <br /> <br /> <span> Необходимо выполнить следующие действия:<br /> Выбрать метод оплаты МТС iPay;<br /> Ввести свой номер мобильного телефона;<br /> Получить сеансовый пароль  отправив любое SMS на номер 5533 (стоимость отправки SMS 105 рублей на любом тарифном плане);<br /> После успешного входа в систему осуществить платеж.<br /> <strong>Внимание! Минимальная сумма остатка на балансе мобильного телефона после оплаты - 1000 бел. руб.</strong><br /> Если операция прошла успешно, Вы получите чек в электронном виде. Чтобы  получить официальный документ, подтверждающий факт оплаты (при  необходимости), обратитесь в любое отделение &laquo;Паритетбанка&raquo;. Адреса  указаны на сайте ОАО &laquo;Паритетбанк&raquo;. </span></td>\n</tr>\n</tbody>\n</table>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1310991556, 1310991556, 1310995744, 7, 3, 0),
(77, 'Договором публичной оферты', '', 'oferta', '', 'настоящий, договор, адресован, физическим, лицам, зарегистрированным, сайте, сети, интернет, www, bongo, далее, именуемым, подписчик, является, официальным, публичным, предложением, лица, указанного, приложении, настоящему, договору, продавец, лице, ооо, реневью, именуемый, представитель, действующего', 'Настоящий договор, адресован физическим лицам  зарегистрированным на сайте в сети Интернет: www.bongo.by, далее  именуемым Подписчик, и является официальным и публичным предложением  лица, указанного в Приложении к настоящему договору, далее именуемым  П', '<div>\n<p>Настоящий договор, адресован физическим лицам  зарегистрированным на сайте в сети Интернет: www.bongo.by, далее  именуемым &laquo;Подписчик&raquo;, и является официальным и публичным предложением  лица, указанного в Приложении к настоящему договору, далее именуемым  &laquo;Продавец&raquo;, в лице ООО &laquo;Реневью&raquo;, далее именуемый &laquo;Представитель&raquo;,  действующего от имени и за счет Продавца, заключить договор, предмет и  условия которого указаны в Приложении к настоящему договору, заключили  настоящий договор (далее &ndash; Договор) о нижеследующем:</p>\n<p>1. Полным и безоговорочным согласием  заключить Договор (далее &ndash; Акцептом) является регистрация на сайте  Представителя в сети Интернет: www.bongo.by (далее &ndash; Сайт), и  осуществление оплаты, предусмотренной пунктом 7 Договора.</p>\n<p>2. Акцепт Договора означает, что Подписчик  согласен со всеми положениями настоящего предложения, и равносилен  заключению Договора и приложений к нему.</p>\n<p>3. Предмет, условия и срок действия Договора устанавливается в соответствующем Приложении к нему.</p>\n<p>4. Приложения к Договору является его  неотъемлемой частью. Все условия, содержащиеся в Приложениях к Договору,  являются условиями Договора.</p>\n<p>5. Приложение к Договору размещается на главной странице Cайта, содержащей предмет, условия и срок сделки с Продавцом.</p>\n<p>6. Полномочия Представителя ограничиваются  размещением на Сайте предмета и условий сделки от имени и за счет  Продавца, а также зачислением денежных средств Подписчика, в порядке,  предусмотренном пунктом 7 Договора. Права и обязанности по Договору  возникают непосредственно у Подписчика и Продавца. Все претензии к  предмету и условиям договора предъявляются Продавцу. Представитель не  несет ответственности за исполнение Продавцом Договора.</p>\n<p>7. Подписчик перечисляет сумму в размере,  указанном в соответствующем Приложении к Договору, на расчетный счет  Представителя. Перечисление суммы может производиться посредством  интернет платежей, безналичного, а также наличного, расчета.</p>\n<p>8. Все расходы по уплате суммы, указанной в пункте 7 Договора, несет Подписчик.</p>\n<p>9. Возникновение прав и обязанностей  Продавца и Подписчика по Договору зависит от наступления следующего  условия, относительно которого сторонам Договора неизвестно, наступит  оно или не наступит, а именно: акцепта Договора другими подписчиками,  минимальное количество которых, а также сроки действия официального и  публичного предложения указывается в соответствующем Приложении к  Договору.</p>\n<p>10. В случае не наступления условий,  указанных в пункте 9 Договора, денежные средства Подписчика,  перечисленные Представителю, остаются на счете Представителя, который по  требованию Подписчика, обязан зачесть указанные денежные средства в  счет оплаты последующих официальных и публичным предложений лиц,  представителем которых является или будет являться Представитель.  Проценты на указанные денежные средства не начисляются, а также иные  штрафные санкции не применяются.</p>\n<p>11.В случае, если Подписчик по каким-либо  причинам не смог воспользоваться приобретенным предложением в указанные  сроки, то денежная сумма Подписчику не возвращается.</p>\n<p>12. Доказательством заключения Договора  Подписчиком является предъявление уникального кода Продавцу, который  присваивается Подписчику после регистрации на Сайте и оплаты  соответсвующего предложения. Любые иные доказательства заключения  Договора Продавцом не рассматриваются.</p>\n<p>13. Порядок обмена информацией между Продавцом и Подписчиком определяется и доводится до сведения Подписчика на Сайте.</p>\n</div>\n<h5>Реквизиты</h5>\n<p>ООО &laquo;Реневью&raquo;<br /> Юридический адрес: 220113, г. Минск, ул. Мележа, 1, офис 734<br /><br /> Банковские реквизиты:<br /> ОАО "Приорбанк" г.Минск ЦБУ 113, код.749<br /> р/с 3012015393117<br /> УНП 191118784<br /> тел. +375 (17) 268-50-54</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1310995507, 1310995507, 1311337666, 4, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `content_fields`
--

CREATE TABLE IF NOT EXISTS `content_fields` (
  `field_name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `group` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL,
  `in_search` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`field_name`),
  UNIQUE KEY `field_name` (`field_name`),
  KEY `type` (`type`),
  KEY `in_search` (`in_search`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_fields`
--

INSERT INTO `content_fields` (`field_name`, `type`, `label`, `data`, `group`, `weight`, `in_search`) VALUES
('field_field1', 'text', 'Field 1', '', 7, 1, 1),
('field_pole2', 'select', 'Pole 2', 'a:3:{s:7:"initial";s:13:"value1\nvalue2";s:9:"help_text";s:0:"";s:10:"validation";s:0:"";}', 7, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `content_fields_data`
--

CREATE TABLE IF NOT EXISTS `content_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `item_type` (`item_type`),
  KEY `field_name` (`field_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `content_fields_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_field_groups`
--

CREATE TABLE IF NOT EXISTS `content_field_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `content_field_groups`
--

INSERT INTO `content_field_groups` (`id`, `name`, `description`) VALUES
(7, 'test', 'sdfsdfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `content_permissions`
--

CREATE TABLE IF NOT EXISTS `content_permissions` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `page_id` bigint(11) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `content_permissions`
--

INSERT INTO `content_permissions` (`id`, `page_id`, `data`) VALUES
(21, 35, 'a:3:{i:0;a:1:{s:7:"role_id";s:1:"0";}i:1;a:1:{s:7:"role_id";s:1:"1";}i:2;a:1:{s:7:"role_id";s:1:"2";}}');

-- --------------------------------------------------------

--
-- Table structure for table `content_tags`
--

CREATE TABLE IF NOT EXISTS `content_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `content_tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `gallery_albums`
--

CREATE TABLE IF NOT EXISTS `gallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `cover_id` int(11) DEFAULT '0',
  `position` int(9) DEFAULT '0',
  `created` int(11) DEFAULT NULL,
  `updated` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `gallery_albums`
--

INSERT INTO `gallery_albums` (`id`, `category_id`, `name`, `description`, `cover_id`, `position`, `created`, `updated`) VALUES
(1, 1, 'new album', '', 0, 0, 1264086406, 1307538865);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_category`
--

CREATE TABLE IF NOT EXISTS `gallery_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `cover_id` int(11) DEFAULT '0',
  `position` int(9) DEFAULT '0',
  `created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `position` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `gallery_category`
--

INSERT INTO `gallery_category` (`id`, `name`, `description`, `cover_id`, `position`, `created`) VALUES
(1, 'test category', '', 0, 0, 1264086398);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE IF NOT EXISTS `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) DEFAULT NULL,
  `file_name` varchar(150) DEFAULT NULL,
  `file_ext` varchar(8) DEFAULT NULL,
  `file_size` varchar(20) DEFAULT NULL,
  `position` int(9) DEFAULT NULL,
  `width` int(6) DEFAULT NULL,
  `height` int(6) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `uploaded` int(11) DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `album_id` (`album_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `album_id`, `file_name`, `file_ext`, `file_size`, `position`, `width`, `height`, `description`, `uploaded`, `views`) VALUES
(18, 1, 'test', '.jpg', '201.3 Кб', 1, 800, 600, NULL, 1266935445, 229),
(19, 1, 'Frangipani_Flowers', '.jpg', '53.2 Кб', 2, 800, 600, NULL, 1266935848, 231),
(37, 1, 'flowers', '.jpg', '81.8 Кб', 4, 800, 600, NULL, 1307538860, 0),
(36, 1, 'winter', '.jpg', '103.1 Кб', 3, 800, 600, NULL, 1307538860, 0);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(100) NOT NULL,
  `identif` varchar(10) NOT NULL,
  `image` text NOT NULL,
  `folder` varchar(100) NOT NULL,
  `template` varchar(100) NOT NULL,
  `default` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `identif` (`identif`),
  KEY `default` (`default`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `lang_name`, `identif`, `image`, `folder`, `template`, `default`) VALUES
(3, 'Русский', 'ru', '', 'russian', 'default', 1),
(30, 'ua', 'ua', '', 'english', 'commerce', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `login_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `username`, `message`, `date`) VALUES
(42, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/72''); return false;">Как это работает</a>', 1310982091),
(43, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/72''); return false;">Как это работает</a>', 1310982135),
(44, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/73''); return false;">Вопросы и поддержка</a>', 1310982164),
(45, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/73''); return false;">Вопросы и поддержка</a>', 1310982754),
(46, 1, 'admin', 'Изменил настройки сайта', 1310982761),
(47, 1, 'admin', 'Изменил настройки сайта', 1310982883),
(48, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/73''); return false;">Вопросы и поддержка</a>', 1310983659),
(49, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/72''); return false;">Как это работает</a>', 1310983701),
(50, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/72''); return false;">Как это работает</a>', 1310989108),
(51, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/74''); return false;">Новая игровая зона в Rubin Plaza</a>', 1310990763),
(52, 1, 'admin', '\n                        Изменил категорию   \n                        <a href="#" onclick="edit_category(56); return false;">Новости и акции</a>', 1310990779),
(53, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/74''); return false;">Новая игровая зона в Rubin Plaza</a>', 1310990789),
(54, 1, 'admin', '\n                        Изменил категорию   \n                        <a href="#" onclick="edit_category(56); return false;">Новости и акции</a>', 1310990847),
(55, 1, 'admin', '\n                        Изменил категорию   \n                        <a href="#" onclick="edit_category(56); return false;">Новости и акции</a>', 1310990942),
(56, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/74''); return false;">Новая игровая зона в Rubin Plaza</a>', 1310991115),
(57, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/74''); return false;">Новая игровая зона в Rubin Plaza</a>', 1310991143),
(58, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/75''); return false;">Поставщикам</a>', 1310991304),
(59, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/76''); return false;">Способы оплаты</a>', 1310991584),
(60, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/76''); return false;">Способы оплаты</a>', 1310991680),
(61, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/65''); return false;">Оплата</a>', 1310993429),
(62, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/65''); return false;">Оплата</a>', 1310993799),
(63, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/65''); return false;">Оплата</a>', 1310993910),
(64, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/65''); return false;">Оплата</a>', 1310994005),
(65, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/65''); return false;">Оплата</a>', 1310994059),
(66, 1, 'admin', '\n            Создал страницу \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/77''); return false;">Договором публичной оферты</a>', 1310995548),
(67, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/73''); return false;">Вопросы и поддержка</a>', 1310995601),
(68, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/72''); return false;">Как это работает</a>', 1310995625),
(69, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/76''); return false;">Способы оплаты</a>', 1310995744),
(70, 1, 'admin', 'Изменил настройки модуля user_manager', 1311000045),
(71, 1, 'admin', 'Вошел в панель управления IP 127.0.0.1', 1311062875),
(72, 1, 'admin', '\n            Изменил страницу  \n            <a href="#" onclick="ajax_div(''page'',''http://kupontut.il/admin/pages/edit/77''); return false;">Договором публичной оферты</a>', 1311337666),
(73, 1, 'admin', 'Очистил кеш', 1311544859),
(74, 1, 'admin', 'Очистил кеш', 1311545677);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `main_title` varchar(300) NOT NULL,
  `tpl` varchar(255) DEFAULT NULL,
  `expand_level` int(255) DEFAULT NULL,
  `description` text,
  `created` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES
(1, 'main_menu', 'Главное меню', '0', 0, NULL, '2010-04-27 13:54:43');

-- --------------------------------------------------------

--
-- Table structure for table `menus_data`
--

CREATE TABLE IF NOT EXISTS `menus_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(9) NOT NULL,
  `item_id` int(9) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `roles` text,
  `hidden` smallint(1) NOT NULL DEFAULT '0',
  `title` varchar(300) NOT NULL,
  `parent_id` int(9) NOT NULL,
  `position` smallint(5) DEFAULT NULL,
  `description` text,
  `add_data` text,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `menus_data`
--

INSERT INTO `menus_data` (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES
(1, 1, 0, 'url', '', '', 0, 'Главная', 0, 4, NULL, '/'),
(2, 1, 51, 'category', '', '', 0, 'Блог', 0, 3, NULL, NULL),
(3, 1, 0, 'module', '', '', 0, 'Обратная связь', 0, 1, NULL, 'a:2:{s:8:"mod_name";s:8:"feedback";s:6:"method";s:0:"";}'),
(4, 1, 0, 'module', '', '', 0, 'Галерея', 0, 2, NULL, 'a:2:{s:8:"mod_name";s:7:"gallery";s:6:"method";s:0:"";}');

-- --------------------------------------------------------

--
-- Table structure for table `menu_translate`
--

CREATE TABLE IF NOT EXISTS `menu_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `menu_translate`
--


-- --------------------------------------------------------

--
-- Table structure for table `my_coupons`
--

CREATE TABLE IF NOT EXISTS `my_coupons` (
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `my_coupons`
--

INSERT INTO `my_coupons` (`user_id`, `product_id`) VALUES
(1, 75),
(1, 76);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `data` text,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `role_id`, `data`) VALUES
(1, 2, 'a:36:{s:9:"cp_access";s:1:"1";s:13:"cp_autoupdate";s:1:"1";s:14:"cp_page_search";s:1:"1";s:11:"lang_create";s:1:"1";s:9:"lang_edit";s:1:"1";s:11:"lang_delete";s:1:"1";s:16:"cp_site_settings";s:1:"1";s:11:"cache_clear";s:1:"1";s:11:"page_create";s:1:"1";s:9:"page_edit";s:1:"1";s:11:"page_delete";s:1:"1";s:15:"category_create";s:1:"1";s:13:"category_edit";s:1:"1";s:15:"category_delete";s:1:"1";s:14:"module_install";s:1:"1";s:16:"module_deinstall";s:1:"1";s:12:"module_admin";s:1:"1";s:13:"widget_create";s:1:"1";s:13:"widget_delete";s:1:"1";s:22:"widget_access_settings";s:1:"1";s:11:"menu_create";s:1:"1";s:9:"menu_edit";s:1:"1";s:11:"menu_delete";s:1:"1";s:11:"user_create";s:1:"1";s:21:"user_create_all_roles";s:1:"1";s:9:"user_edit";s:1:"1";s:11:"user_delete";s:1:"1";s:14:"user_view_data";s:1:"1";s:14:"xfields_create";s:1:"1";s:14:"xfields_delete";s:1:"1";s:12:"xfields_edit";s:1:"1";s:12:"roles_create";s:1:"1";s:10:"roles_edit";s:1:"1";s:12:"roles_delete";s:1:"1";s:9:"logs_view";s:1:"1";s:13:"backup_create";s:1:"1";}');

-- --------------------------------------------------------

--
-- Table structure for table `propel_migration`
--

CREATE TABLE IF NOT EXISTS `propel_migration` (
  `version` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `propel_migration`
--

INSERT INTO `propel_migration` (`version`) VALUES
(1307623010);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(30) NOT NULL,
  `alt_name` varchar(50) NOT NULL,
  `desc` varchar(300) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `parent_id`, `name`, `alt_name`, `desc`) VALUES
(1, 0, 'user', 'Пользователи', ''),
(2, 0, 'admin', 'Администраторы', '');

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE IF NOT EXISTS `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(264) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `where_array` text,
  `select_array` text,
  `table_name` varchar(100) DEFAULT NULL,
  `order_by` text,
  `row_count` int(11) DEFAULT NULL,
  `total_rows` int(11) DEFAULT NULL,
  `ids` text,
  `search_title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`),
  KEY `datetime` (`datetime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `search`
--


-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(50) NOT NULL,
  `site_title` varchar(200) NOT NULL,
  `site_short_title` varchar(50) NOT NULL,
  `site_description` varchar(200) NOT NULL,
  `site_keywords` varchar(200) NOT NULL,
  `create_keywords` varchar(25) NOT NULL,
  `create_description` varchar(25) NOT NULL,
  `create_cat_keywords` varchar(25) NOT NULL,
  `create_cat_description` varchar(25) NOT NULL,
  `add_site_name` int(1) NOT NULL,
  `add_site_name_to_cat` int(1) NOT NULL,
  `delimiter` varchar(5) NOT NULL,
  `editor_theme` varchar(10) NOT NULL,
  `site_template` varchar(50) NOT NULL,
  `site_offline` varchar(5) NOT NULL,
  `main_type` varchar(50) NOT NULL,
  `main_page_id` int(11) NOT NULL,
  `main_page_cat` text NOT NULL,
  `main_page_module` varchar(50) NOT NULL,
  `sidepanel` varchar(5) NOT NULL,
  `lk` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `s_name` (`s_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `s_name`, `site_title`, `site_short_title`, `site_description`, `site_keywords`, `create_keywords`, `create_description`, `create_cat_keywords`, `create_cat_description`, `add_site_name`, `add_site_name_to_cat`, `delimiter`, `editor_theme`, `site_template`, `site_offline`, `main_type`, `main_page_id`, `main_page_cat`, `main_page_module`, `sidepanel`, `lk`) VALUES
(2, 'main', 'KuponTut.by', 'KuponTut.by', 'купоны', 'купоны', 'auto', 'auto', '0', '0', 1, 1, '/', 'advanced', 'kupon', 'no', 'module', 35, '1', 'shop', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_brands`
--

CREATE TABLE IF NOT EXISTS `shop_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_brands_I_1` (`name`(333)),
  KEY `shop_brands_I_2` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `shop_brands`
--

INSERT INTO `shop_brands` (`id`, `name`, `url`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES
(10, 'LG', '10', '<p><strong>LG Group</strong> (&laquo;Lucky Goldstar&raquo;, <a title="Корейский язык" href="http://ru.wikipedia.org/wiki/%D0%9A%D0%BE%D1%80%D0%B5%D0%B9%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">кор.</a> <span style="font-size: 110%;" lang="ko">LG??</span>)&nbsp;&mdash; третья по величине корпорация (бизнес-конгломерат&nbsp;&mdash; <a title="Чеболь" href="http://ru.wikipedia.org/wiki/%D0%A7%D0%B5%D0%B1%D0%BE%D0%BB%D1%8C">чеболь</a>) <a title="Южная Корея" href="http://ru.wikipedia.org/wiki/%D0%AE%D0%B6%D0%BD%D0%B0%D1%8F_%D0%9A%D0%BE%D1%80%D0%B5%D1%8F">Южной Кореи</a>,  производящая бытовую электронику, химическую продукцию и  телекоммуникационное оборудование и имеющая дочерние компании LG  Electronics, LG Display, LG Telecom и LG Chem в более чем 80 странах.  Штаб-квартира компании находится в <a title="Сеул" href="http://ru.wikipedia.org/wiki/%D0%A1%D0%B5%D1%83%D0%BB">Сеуле</a>.<sup id="cite_ref-b_0-0"><a href="http://ru.wikipedia.org/wiki/LG#cite_note-b-0">[1]</a></sup></p>', '', '', ''),
(11, 'Panasonic', '11', '<p><strong>Panasonic Corporation</strong> <span style="font-weight: normal;">(<a title="Японский язык" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">яп.</a> <span style="font-size: 110%;" lang="ja">??????????</span> <em>панасоникку кабусикигайся</em><span><a title="Википедия:Японский язык" href="http://ru.wikipedia.org/wiki/%D0%92%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA"><sup style="color: #0000ee; font: bold 80% sans-serif; text-decoration: none; padding-left: 0.1em;">?</sup></a></span>)</span>&nbsp;&mdash;  крупная японская машиностроительная корпорация, один из крупнейших в  мире производителей бытовой техники и электронных товаров. В 2007 году  компания заняла 59-е место по объёму выручки в глобальном рейтинге  компаний <a title="Fortune Global 500" href="http://ru.wikipedia.org/wiki/Fortune_Global_500">Fortune Global 500</a><sup id="cite_ref-0"><a href="http://ru.wikipedia.org/wiki/Panasonic#cite_note-0">[1]</a></sup>. До 1 октября <a title="2008 год" href="http://ru.wikipedia.org/wiki/2008_%D0%B3%D0%BE%D0%B4">2008 года</a> носила название Matsushita Electric Industrial Co., Ltd. (Panasonic  была одной из торговых марок этой компании). Штаб-квартира&nbsp;&mdash; в городе <a title="Кадома, Осака (страница отсутствует)" href="http://ru.wikipedia.org/w/index.php?title=%D0%9A%D0%B0%D0%B4%D0%BE%D0%BC%D0%B0,_%D0%9E%D1%81%D0%B0%D0%BA%D0%B0&amp;action=edit&amp;redlink=1">Кадома</a> <a title="Префектура Осака" href="http://ru.wikipedia.org/wiki/%D0%9F%D1%80%D0%B5%D1%84%D0%B5%D0%BA%D1%82%D1%83%D1%80%D0%B0_%D0%9E%D1%81%D0%B0%D0%BA%D0%B0">префектуры Осака</a> (<a title="Япония" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D0%B8%D1%8F">Япония</a>).</p>', '', '', ''),
(12, 'Samsung', '12', '', '', '', ''),
(9, 'Sony', '9', '', '', '', ''),
(13, 'Calypso', 'calypso', '', '', '', ''),
(14, 'Philips', 'philips', '', '', '', ''),
(15, 'Yamaha', '15', '', '', '', ''),
(16, 'Canon', 'canon', '<p>Корпорация <strong>Кэ?нон</strong> (<a title="Английский язык" href="http://ru.wikipedia.org/wiki/%D0%90%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">англ.</a>&nbsp;<em><span lang="en">Canon Inc.</span></em>, <a title="Японский язык" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">яп.</a> <span style="font-size: 110%;" lang="ja">????????,</span> <em>Кянон кабусики гайся</em>) (<a title="Токийская фондовая биржа" href="http://ru.wikipedia.org/wiki/%D0%A2%D0%BE%D0%BA%D0%B8%D0%B9%D1%81%D0%BA%D0%B0%D1%8F_%D1%84%D0%BE%D0%BD%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F_%D0%B1%D0%B8%D1%80%D0%B6%D0%B0">TYO</a>: <a rel="nofollow" href="http://stocks.us.reuters.com/stocks/overview.asp?symbol=7751.T"><strong>7751</strong></a>, <span><a title="Нью-Йоркская фондовая биржа" href="http://ru.wikipedia.org/wiki/%D0%9D%D1%8C%D1%8E-%D0%99%D0%BE%D1%80%D0%BA%D1%81%D0%BA%D0%B0%D1%8F_%D1%84%D0%BE%D0%BD%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F_%D0%B1%D0%B8%D1%80%D0%B6%D0%B0">NYSE</a>: <a rel="nofollow" href="http://www.nyse.com/about/listed/lcddata.html?ticker=CAJ"><strong>CAJ</strong></a></span>)&nbsp;&mdash;  японская машиностроительная компания, один из мировых лидеров в области  создания цифрового оборудования для использования в офисе и дома. Со  времени основания в <a title="1937" href="http://ru.wikipedia.org/wiki/1937">1937</a>&nbsp;г. компания Canon заняла уверенные позиции в сферах <a title="Фотоаппарат" href="http://ru.wikipedia.org/wiki/%D0%A4%D0%BE%D1%82%D0%BE%D0%B0%D0%BF%D0%BF%D0%B0%D1%80%D0%B0%D1%82">фото-</a>, <a title="Видеокамера" href="http://ru.wikipedia.org/wiki/%D0%92%D0%B8%D0%B4%D0%B5%D0%BE%D0%BA%D0%B0%D0%BC%D0%B5%D1%80%D0%B0">видеотехники</a> и <a title="Информационные технологии" href="http://ru.wikipedia.org/wiki/%D0%98%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D0%BE%D0%BD%D0%BD%D1%8B%D0%B5_%D1%82%D0%B5%D1%85%D0%BD%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D0%B8">информационных технологий</a>. Главный офис компании расположен в <a title="Токио" href="http://ru.wikipedia.org/wiki/%D0%A2%D0%BE%D0%BA%D0%B8%D0%BE">Токио</a> (<a title="Япония" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D0%B8%D1%8F">Япония</a>)</p>', 'Canon', 'Canon', 'Canon'),
(17, 'Epson', 'epson', '<p><strong>Seiko Epson Corporation</strong> <span style="font-weight: normal;">(<a title="Японский язык" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">яп.</a> <span style="font-size: 110%;" lang="ja">????????????</span> <em>сэйко:эпусон кабусикигайся</em><span><a title="Википедия:Японский язык" href="http://ru.wikipedia.org/wiki/%D0%92%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA"><sup style="color: #0000ee; font: bold 80% sans-serif; text-decoration: none; padding-left: 0.1em;">?</sup></a></span>, Сейко Эпсон Корпорейшн)</span>&nbsp;&mdash; структурное подразделение японского многоотраслевого концерна <a title="Seiko Group (страница отсутствует)" href="http://ru.wikipedia.org/w/index.php?title=Seiko_Group&amp;action=edit&amp;redlink=1">Seiko Group</a>. Один из крупнейших производителей струйных, матричных и лазерных <a title="Принтер" href="http://ru.wikipedia.org/wiki/%D0%9F%D1%80%D0%B8%D0%BD%D1%82%D0%B5%D1%80">принтеров</a>, <a title="Сканер" href="http://ru.wikipedia.org/wiki/%D0%A1%D0%BA%D0%B0%D0%BD%D0%B5%D1%80">сканеров</a>, настольных компьютеров, проекторов, а также других электронных компонентов. Компания базируется в <a title="Япония" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D0%B8%D1%8F">Японии</a> и имеет множество дочерних компаний по всему миру.</p>', '', '', ''),
(18, 'Plantronics', 'plantronics', '', '', '', ''),
(19, 'Motorola', 'motorola', '<p><strong>Motorola Inc.</strong> (<span><a title="Нью-Йоркская фондовая биржа" href="http://ru.wikipedia.org/wiki/%D0%9D%D1%8C%D1%8E-%D0%99%D0%BE%D1%80%D0%BA%D1%81%D0%BA%D0%B0%D1%8F_%D1%84%D0%BE%D0%BD%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F_%D0%B1%D0%B8%D1%80%D0%B6%D0%B0">NYSE</a>: <a rel="nofollow" href="http://www.nyse.com/about/listed/lcddata.html?ticker=MOT"><strong>MOT</strong></a></span>)&nbsp;&mdash; один из мировых лидеров в области интегрированных телекоммуникаций, и встроенных электронных систем, входит в список <a title="Fortune 100 (страница отсутствует)" href="http://ru.wikipedia.org/w/index.php?title=Fortune_100&amp;action=edit&amp;redlink=1">Fortune 100</a> крупнейших компаний в <a title="США" href="http://ru.wikipedia.org/wiki/%D0%A1%D0%A8%D0%90">США</a>. Штаб-квартира&nbsp;&mdash; в <a title="Шаумбург (Иллинойс) (страница отсутствует)" href="http://ru.wikipedia.org/w/index.php?title=%D0%A8%D0%B0%D1%83%D0%BC%D0%B1%D1%83%D1%80%D0%B3_%28%D0%98%D0%BB%D0%BB%D0%B8%D0%BD%D0%BE%D0%B9%D1%81%29&amp;action=edit&amp;redlink=1">Шаумбурге</a>, неподалеку от <a title="Чикаго" href="http://ru.wikipedia.org/wiki/%D0%A7%D0%B8%D0%BA%D0%B0%D0%B3%D0%BE">Чикаго</a>, штат <a title="Иллинойс" href="http://ru.wikipedia.org/wiki/%D0%98%D0%BB%D0%BB%D0%B8%D0%BD%D0%BE%D0%B9%D1%81">Иллинойс</a> (США).</p>', '', '', ''),
(20, 'Pioneer', 'pioneer', '', '', '', ''),
(21, 'Pyle', 'pyle', '', '', '', ''),
(22, 'JVC', 'jvc', '<p><strong>Japan Victor Company Ltd. (JVC)</strong> <span style="font-weight: normal;">(<a title="Японский язык" href="http://ru.wikipedia.org/wiki/%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA">яп.</a> <span style="font-size: 110%;" lang="ja">??????????</span> <em>Нихон бикута: кабусикигайся</em><span><a title="Википедия:Японский язык" href="http://ru.wikipedia.org/wiki/%D0%92%D0%B8%D0%BA%D0%B8%D0%BF%D0%B5%D0%B4%D0%B8%D1%8F:%D0%AF%D0%BF%D0%BE%D0%BD%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA"><sup style="color: #0000ee; font: bold 80% sans-serif; text-decoration: none; padding-left: 0.1em;">?</sup></a></span>)</span> (<a title="Токийская фондовая биржа" href="http://ru.wikipedia.org/wiki/%D0%A2%D0%BE%D0%BA%D0%B8%D0%B9%D1%81%D0%BA%D0%B0%D1%8F_%D1%84%D0%BE%D0%BD%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F_%D0%B1%D0%B8%D1%80%D0%B6%D0%B0">TYO</a>: <a rel="nofollow" href="http://stocks.us.reuters.com/stocks/overview.asp?symbol=6792.T"><strong>6792</strong></a>)&nbsp;&mdash; японская компания, разработчик формата видеозаписи <a title="VHS" href="http://ru.wikipedia.org/wiki/VHS">VHS</a>. Штаб-квартира&nbsp;&mdash; в <a title="Иокогама" href="http://ru.wikipedia.org/wiki/%D0%98%D0%BE%D0%BA%D0%BE%D0%B3%D0%B0%D0%BC%D0%B0">Иокогаме</a>.</p>\n<p>Основана в <a title="1927 год" href="http://ru.wikipedia.org/wiki/1927_%D0%B3%D0%BE%D0%B4">1927 году</a>.</p>\n<p>C середины 60-х годов контрольный пакет принадлежит компании <a title="Matsushita" href="http://ru.wikipedia.org/wiki/Matsushita">Matsushita</a> (владельцу торговой марки <a title="Panasonic (торговая марка)" href="http://ru.wikipedia.org/wiki/Panasonic_%28%D1%82%D0%BE%D1%80%D0%B3%D0%BE%D0%B2%D0%B0%D1%8F_%D0%BC%D0%B0%D1%80%D0%BA%D0%B0%29">Panasonic</a>).</p>', '', '', ''),
(23, 'Garmin', 'garmin', '<p><strong>Garmin Ltd.</strong>&nbsp;&mdash; производитель <a title="GPS" href="http://ru.wikipedia.org/wiki/GPS">GPS</a>-навигационной техники.</p>\n<p>Компания была основана в <a title="1989 год" href="http://ru.wikipedia.org/wiki/1989_%D0%B3%D0%BE%D0%B4">1989 году</a> в городе <a title="Олатэ (Канзас) (страница отсутствует)" href="http://ru.wikipedia.org/w/index.php?title=%D0%9E%D0%BB%D0%B0%D1%82%D1%8D_%28%D0%9A%D0%B0%D0%BD%D0%B7%D0%B0%D1%81%29&amp;action=edit&amp;redlink=1">Олатэ</a> (<a title="США" href="http://ru.wikipedia.org/wiki/%D0%A1%D0%A8%D0%90">США</a>). Европейское представительство находится в <a title="Великобритания" href="http://ru.wikipedia.org/wiki/%D0%92%D0%B5%D0%BB%D0%B8%D0%BA%D0%BE%D0%B1%D1%80%D0%B8%D1%82%D0%B0%D0%BD%D0%B8%D1%8F">Великобритании</a>.</p>\n<p>Garmin производит <a title="GPS-приёмник" href="http://ru.wikipedia.org/wiki/GPS-%D0%BF%D1%80%D0%B8%D1%91%D0%BC%D0%BD%D0%B8%D0%BA">навигаторы</a> для воздушного, автомобильного, мото- и водного транспорта, а также для туристов и спортсменов.</p>', '', '', ''),
(24, 'TomTom', 'tomtom', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_category`
--

CREATE TABLE IF NOT EXISTS `shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `description` text,
  `meta_desc` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `full_path` varchar(1000) DEFAULT NULL,
  `full_path_ids` varchar(250) DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_category_I_1` (`name`),
  KEY `shop_category_I_2` (`url`),
  KEY `shop_category_I_3` (`active`),
  KEY `shop_category_I_4` (`parent_id`),
  KEY `shop_category_I_5` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `shop_category`
--

INSERT INTO `shop_category` (`id`, `name`, `url`, `description`, `meta_desc`, `meta_title`, `meta_keywords`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`) VALUES
(52, 'Гродно', 'grodno', '', '', '', '', 0, 17, 'grodno', 'a:0:{}', 1),
(51, 'Bluetooth', 'bluetooth', '', '', '', '', 48, 16, 'domashniaia_elektronika/bluetooth', 'a:1:{i:0;i:48;}', 1),
(50, 'Телефоны', 'telefony', '', '', '', '', 48, 15, 'domashniaia_elektronika/telefony', 'a:1:{i:0;i:48;}', 1),
(48, 'Гомель', 'gomel', '', '', '', '', 0, 13, 'gomel', 'a:0:{}', 1),
(46, 'Фотопринтеры', 'fotoprintery', '', '', '', '', 44, 11, 'foto_i_kamery/fotoprintery', 'a:1:{i:0;i:44;}', 1),
(45, 'Цифровые камеры', 'tsifrovye_kamery', '', '', '', '', 44, 10, 'foto_i_kamery/tsifrovye_kamery', 'a:1:{i:0;i:44;}', 1),
(44, 'Витебск', 'vitebsk', '', '', '', '', 0, 9, 'vitebsk', 'a:0:{}', 1),
(43, 'Спикеры', 'saund_bary', '', '', '', '', 40, 8, 'domashnee_audio/saund_bary', 'a:1:{i:0;i:40;}', 1),
(41, 'Домашние театры', 'domashnie_teatry', '', '', '', '', 40, 6, 'domashnee_audio/domashnie_teatry', 'a:1:{i:0;i:40;}', 1),
(40, 'Брест', 'brest', '', '', '', '', 0, 5, 'brest', 'a:0:{}', 1),
(36, 'Минск', 'minsk', '', '', '', '', 0, 1, 'minsk', 'a:0:{}', 1),
(37, 'Текущие акции', 'current_stock', '', '', '', '', 36, 2, 'minsk/current_stock', 'a:1:{i:0;i:36;}', 1),
(38, 'Прошедшие акции', 'past_actions', '', '', '', '', 36, 3, 'minsk/past_actions', 'a:1:{i:0;i:36;}', 1),
(53, 'Сабвуферы', 'subwoofer', '', '', '', '', 52, 18, 'avto_muzyka_i_video/subwoofer', 'a:1:{i:0;i:52;}', 1),
(54, 'CD Ченджеры', 'cd_chendzhery', '', '', '', '', 52, 19, 'avto_muzyka_i_video/cd_chendzhery', 'a:1:{i:0;i:52;}', 1),
(55, 'GPS', 'gps', '', '', '', '', 52, 20, 'avto_muzyka_i_video/gps', 'a:1:{i:0;i:52;}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_currencies`
--

CREATE TABLE IF NOT EXISTS `shop_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `main` tinyint(4) DEFAULT NULL,
  `is_default` tinyint(4) DEFAULT NULL,
  `code` varchar(5) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `rate` float(6,3) DEFAULT '1.000',
  PRIMARY KEY (`id`),
  KEY `shop_currencies_I_1` (`name`),
  KEY `shop_currencies_I_2` (`main`),
  KEY `shop_currencies_I_3` (`is_default`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shop_currencies`
--

INSERT INTO `shop_currencies` (`id`, `name`, `main`, `is_default`, `code`, `symbol`, `rate`) VALUES
(1, 'Доллары', 0, 0, 'USD', '$', 1.000),
(2, 'Рубли', 1, 1, 'RUR', 'руб', 1.000);

-- --------------------------------------------------------

--
-- Table structure for table `shop_delivery_methods`
--

CREATE TABLE IF NOT EXISTS `shop_delivery_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `description` text,
  `price` float(10,2) NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `enabled` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_delivery_methods_I_1` (`name`(333)),
  KEY `shop_delivery_methods_I_2` (`enabled`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `shop_delivery_methods`
--

INSERT INTO `shop_delivery_methods` (`id`, `name`, `description`, `price`, `free_from`, `enabled`) VALUES
(7, 'Самовывоз', '', 0.00, 0.00, 1),
(5, 'Курьером', '<p>Только по Киеву и Москве</p>', 0.00, 0.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_delivery_methods_systems`
--

CREATE TABLE IF NOT EXISTS `shop_delivery_methods_systems` (
  `delivery_method_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_method_id`,`payment_method_id`),
  KEY `shop_delivery_methods_systems_FI_2` (`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_delivery_methods_systems`
--

INSERT INTO `shop_delivery_methods_systems` (`delivery_method_id`, `payment_method_id`) VALUES
(5, 1),
(5, 2),
(5, 3),
(5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `shop_discounts`
--

CREATE TABLE IF NOT EXISTS `shop_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `date_start` int(11) DEFAULT NULL,
  `date_stop` int(11) DEFAULT NULL,
  `discount` varchar(11) DEFAULT NULL,
  `min_price` float(10,2) DEFAULT NULL,
  `max_price` float(10,2) DEFAULT NULL,
  `categories` text,
  `products` text,
  `description` text,
  `user_group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shop_discounts`
--

INSERT INTO `shop_discounts` (`id`, `name`, `active`, `date_start`, `date_stop`, `discount`, `min_price`, `max_price`, `categories`, `products`, `description`, `user_group`) VALUES
(4, 'Скидка на Видео технику', 1, 1293829200, 1309377600, '10%', 0.00, 0.00, 'a:3:{i:0;s:2:"37";i:1;s:2:"38";i:2;s:2:"39";}', '', '<p>Скидка на Видео технику в размере 10%</p>', 'N;');

-- --------------------------------------------------------

--
-- Table structure for table `shop_orders`
--

CREATE TABLE IF NOT EXISTS `shop_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `delivery_method` int(11) DEFAULT NULL,
  `delivery_price` float(10,2) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `paid` tinyint(4) DEFAULT NULL,
  `user_full_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `user_deliver_to` varchar(500) DEFAULT NULL,
  `user_comment` varchar(1000) DEFAULT NULL,
  `date_created` int(11) DEFAULT NULL,
  `date_updated` int(11) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_I_1` (`key`),
  KEY `shop_orders_I_2` (`status`),
  KEY `shop_orders_I_3` (`date_created`),
  KEY `shop_orders_FI_1` (`delivery_method`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `shop_orders`
--

INSERT INTO `shop_orders` (`id`, `key`, `delivery_method`, `delivery_price`, `status`, `paid`, `user_full_name`, `user_email`, `user_phone`, `user_deliver_to`, `user_comment`, `date_created`, `date_updated`, `user_ip`, `user_id`) VALUES
(25, '8l49v3y824', NULL, 100.00, 0, 0, 'tester', 'tester@localhost.loc', '099000000', 'test adres', 'comment text', 1302000706, 1302000706, '127.0.0.3', 1),
(27, '38p40u736c', NULL, 100.00, 2, 0, 'Administrator', 'admin@localhost.loc', '0808808080', 'sdfsdfsdf', '', 1302009177, 1302009177, '127.0.0.3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_orders_products`
--

CREATE TABLE IF NOT EXISTS `shop_orders_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_products_I_1` (`order_id`),
  KEY `shop_orders_products_FI_1` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `shop_orders_products`
--

INSERT INTO `shop_orders_products` (`id`, `order_id`, `product_id`, `variant_id`, `product_name`, `variant_name`, `price`, `quantity`) VALUES
(29, 25, 87, 98, 'Sony HT-SS370 Home Theater', '', 349.00, 1),
(31, 27, 94, 105, 'Yamaha NSIW760 Speaker', '', 99.95, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_payment_methods`
--

CREATE TABLE IF NOT EXISTS `shop_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `active` tinyint(4) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `payment_system_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_payment_methods_I_1` (`name`),
  KEY `shop_payment_methods_I_2` (`position`),
  KEY `shop_payment_methods_FI_1` (`currency_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shop_payment_methods`
--

INSERT INTO `shop_payment_methods` (`id`, `name`, `description`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES
(1, 'Оплата курьеру', '<p>Оплата через веб-моней</p>', 1, 1, 1, 'WebMoneySystem'),
(2, 'Оплата через Банк', '<p>Оплата через ОщадБанк Украины</p>', 1, 2, 2, 'OschadBankInvoiceSystem'),
(3, 'СберБанк России', '<p>Оплата через СберБанк России</p>', 1, 2, 3, 'SberBankInvoiceSystem'),
(4, 'Robokassa', '<p>Оплата с помощью Robokassa</p>', 1, 2, 4, 'RobokassaSystem');

-- --------------------------------------------------------

--
-- Table structure for table `shop_products`
--

CREATE TABLE IF NOT EXISTS `shop_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `hit` tinyint(4) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `related_products` varchar(255) DEFAULT NULL,
  `mainImage` varchar(255) DEFAULT NULL,
  `smallImage` varchar(255) DEFAULT NULL,
  `short_description` text,
  `full_description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `old_price` float(10,2) DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `hot` tinyint(4) DEFAULT NULL,
  `action` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_products_I_1` (`name`(333)),
  KEY `shop_products_I_2` (`url`),
  KEY `shop_products_I_3` (`brand_id`),
  KEY `shop_products_I_4` (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=170 ;

--
-- Dumping data for table `shop_products`
--

INSERT INTO `shop_products` (`id`, `name`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`, `created`, `updated`, `old_price`, `views`, `hot`, `action`) VALUES
(71, 'Фильм на выбор в кинотеатре Rubin Plaza. 2 билета со скидкой 52%', 'rubin_plaza', 1, 1, 0, 37, '72,76', '71_main.jpg', '71_small.jpg', '<p>Для того чтобы добиться чего-то в жизни, нужно обладать определенными  качествами. Однако не все из нас в силу воспитания или других факторов  наделены прямолинейностью, целенаправленностью, уверенностью в себе,  оптимизмом&hellip;</p>\r\n\n<ul>\r\n\n<li>Стильное, бескаркасное кресло, на котором удобно сидеть</li>\r\n\n<li>Оригинальный подарок на любой праздник себе и близким</li>\r\n\n<li>Принимает форму тела, подстраивается под Вашу спину</li>\r\n\n<li>Очень практичен благодаря весу и размеру и специальной ткани</li>\r\n\n<li>Многофункционален &mdash; на нем одинаково хорошо и работать, и отдыхать</li>\r\n\n<li>Он понравится и детям &mdash; с ним можно играть</li>\r\n\n<li>Любимое место в доме</li>\r\n\n</ul>', '', '', '', '', 1311861600, 1311543490, 50.00, 24, 1, NULL),
(72, 'Скидка 75% на свежие цветы и изысканные букеты', '72', 1, NULL, 10, 37, '', '72_main.jpg', '72_small.jpg', '<p>Скидка 50% на свежие цветы и изысканные букеты</p>', '', '', '', '', 1312812724, 1311543422, 75.00, 19, 1, NULL),
(73, 'Скидка 50% на тур по Европе с отдыхом на Адриатическом побережье Италии', '73', 1, NULL, 11, 37, '', '73_main.jpg', '73_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1313697600, 1311545016, 40.00, 1, 1, NULL),
(74, '50% скидки на УЗИ органов брюшной полости на уникальном ультразвуковом сканере VOLUSON 730 Expert в Клинике женского здоровья «Ева»!', '74', 1, NULL, 12, 38, '', '74_main.jpg', '74_small.jpg', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', '', 1307543711, 1311165605, 50.00, NULL, 1, NULL),
(75, 'Скидка 60% на нанопокрытие на СТО "Два апельсина"', '75', 1, NULL, 13, 38, '', '75_main.jpg', '75_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1310500800, 1311546286, 60.00, 1, 1, NULL),
(76, 'Скидка 50% на один из комплексов услуг автоцентра "Маяк"', '76', 1, NULL, 13, 37, '72, 73', '76_main.jpg', '76_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1325278800, 1311424414, 50.00, 20, 1, NULL),
(96, 'Canon VIXIA HF R11 Digital', '96', 1, 0, 16, 45, '', '96_main.jpg', '96_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542081, 0, NULL, NULL, NULL, NULL),
(77, '40% скидки на экскурсию в Гродно с посещением АКВАПАРКА!', '77', 1, NULL, 9, 38, '', '77_main.jpg', '77_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542980, 1311171582, 40.00, NULL, NULL, NULL),
(78, '50% скидки на онкологическую профилактику!', '78', 1, NULL, 11, 38, '', '78_main.jpg', '78_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543572, 1311543443, 50.00, NULL, 1, NULL),
(79, '57% скидки на печать визиток!', '79', 1, NULL, 11, 38, '', '79_main.jpg', '79_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544450, 1311166176, 57.00, NULL, NULL, NULL),
(80, '52% скидки на элитную процедуру детоксикации кожи лица', '80', 1, NULL, 10, 38, '', '80_main.jpg', '80_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544569, 1311166221, 52.00, NULL, NULL, NULL),
(81, '50% скидки на аренду квартир!', '81', 1, NULL, 12, 38, '', '81_main.jpg', '81_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544442, 1311166267, 50.00, NULL, NULL, NULL),
(82, 'Скидка 60% на абонемент на 8 занятий по любому направлению фитнес-клуба "Alisa Star"', '82', 1, NULL, 12, 36, '', '82_main.jpg', '82_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542064, 1311074406, 40.00, NULL, NULL, NULL),
(83, 'Sony BDP-S470 Network', '83', NULL, NULL, 9, 36, '', '83_main.jpg', '83_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307545378, 1311073899, 0.00, NULL, 1, NULL),
(84, 'Panasonic DMP-BD45 Ultra-Fast', '84', 1, NULL, 11, 39, '', '84_main.jpg', '84_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541602, 0, NULL, NULL, NULL, NULL),
(85, 'LG BD570 Network Audio', '85', 1, NULL, 10, 39, '', '85_main.jpg', '85_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544238, 0, NULL, NULL, NULL, NULL),
(87, 'Sony HT-SS370 Home Theater', '87', 1, NULL, 9, 41, '', '87_main.jpg', '87_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541766, 0, NULL, NULL, NULL, NULL),
(88, 'Скидка 90% на вход на 6-ой международный байкерский фестиваль "Минск - 2011" в ГСОК "Логойск"!', 'fest', 1, NULL, 12, 41, '', '88_main.jpg', '88_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544977, 1311163681, 90.00, 3, 1, NULL),
(95, 'Canon EOS Rebel T2i 18 Megapixel Digital', '95', 1, NULL, 16, 45, '', '95_main.jpg', '95_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542081, 0, NULL, NULL, NULL, NULL),
(89, 'Panasonic SCPTX7 Home Theater', '89', 1, NULL, 11, 41, '', '89_main.jpg', '89_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541636, 1301492999, 0.00, NULL, NULL, NULL),
(90, 'Samsung HT-C7530W 5.1 Channel', '90', 1, NULL, 12, 41, '', '90_main.jpg', '90_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543337, 0, NULL, NULL, NULL, NULL),
(91, 'Sony BDV-E770W Home Theater', '91', 1, NULL, 9, 41, '', '91_main.jpg', '91_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544214, 1301492801, 0.00, NULL, NULL, NULL),
(92, 'Скидка 80% на тренинг "НЛП-практик" от самого признанного тренера НЛП в РБ Андрея Нелепко', '92', 1, NULL, 12, 43, '', '92_main.jpg', '92_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544791, 1311173297, 80.00, 11, NULL, NULL),
(93, 'Yamaha HS80M Powered Speaker', '93', 1, NULL, 15, 43, '', '93_main.jpg', '93_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542628, 0, NULL, NULL, NULL, NULL),
(94, 'Yamaha NSIW760 Speaker', '94', 1, NULL, 15, 43, '', '94_main.jpg', '94_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544425, 0, NULL, NULL, NULL, NULL),
(97, 'Sony Handycam HDR-CX3', '97', 1, NULL, 9, 45, '', '97_main.jpg', '97_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541628, 0, NULL, NULL, NULL, NULL),
(98, 'Samsung NX10 14 Megapixel Digital', '98', 1, 0, 12, 45, '', '98_main.jpg', '98_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542730, 0, NULL, NULL, NULL, NULL),
(99, 'Samsung NX100 Interchangeable Lens', '99', 1, NULL, 12, 45, '', '99_main.jpg', '99_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543877, 1301492994, 0.00, NULL, NULL, NULL),
(100, 'Canon PIXMA iP100 Photo Printer', '100', 1, NULL, 16, 46, '', '100_main.jpg', '100_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543018, 0, NULL, NULL, NULL, NULL),
(101, 'Canon PIXMA iP4820 Premium', '101', 1, NULL, 16, 46, '', '101_main.jpg', '101_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543107, 0, NULL, NULL, NULL, NULL),
(102, 'Скидка 60% на калифорнийское мелирование в салоне красоты "Эвлин"', '102', 1, NULL, 17, 46, '', '102_main.jpg', '102_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307545161, 1311075515, 36.00, 6, NULL, NULL),
(103, 'Epson Stylus C88+ Inkjet Printer', '103', 1, NULL, 17, 46, '', '103_main.jpg', '103_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543901, 0, NULL, NULL, NULL, NULL),
(104, 'Epson Stylus Photo R2880 Color', '104', 1, NULL, 17, 46, '', '104_main.jpg', '104_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543227, 0, NULL, NULL, NULL, NULL),
(105, 'Panasonic KX-TG6582T Cordless Phone', '105', 1, NULL, 11, 50, '', '105_main.jpg', '105_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543429, 0, NULL, NULL, NULL, NULL),
(106, 'Panasonic KX-TG7433B Expandable', '106', 1, 0, 11, 50, '', '106_main.jpg', '106_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543089, 0, NULL, NULL, NULL, NULL),
(107, 'Plantronics CS70N Wireless Earset', '107', 1, NULL, 18, 50, '', '107_main.jpg', '107_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541701, 0, NULL, NULL, NULL, NULL),
(108, 'Plantronics CS55 Wireless Earset', '108', 1, 0, 18, 50, '', '108_main.jpg', '108_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544069, 0, NULL, 4, NULL, NULL),
(109, 'Panasonic KX-TG6445 Cordless Phone', '109', 1, NULL, 11, 50, '', '109_main.jpg', '109_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307544627, 0, NULL, NULL, NULL, NULL),
(110, 'Motorola H720 Earset - Mono', '110', 1, NULL, 19, 51, '', '110_main.jpg', '110_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543831, 0, NULL, NULL, NULL, NULL),
(111, 'Plantronics Discovery 665 Wireless', '111', 1, NULL, 18, 51, '', '111_main.jpg', '111_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543077, 0, NULL, NULL, NULL, NULL),
(112, 'Motorola H270 Bluetooth Headset', '112', 1, NULL, 19, 51, '', '112_main.jpg', '112_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543753, 0, NULL, NULL, NULL, NULL),
(113, 'LG HBM-210 Bluetooth Headset', '113', 1, NULL, 10, 51, '', '113_main.jpg', '113_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542831, 0, NULL, NULL, NULL, NULL),
(114, 'Samsung AWEP450PBECSTA Bluetooth Headset Black', '114', 1, NULL, 12, 51, '', '114_main.jpg', '114_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543699, 0, NULL, NULL, NULL, NULL),
(115, 'Pioneer TS-SW3041D Shallow-Mount Subwoofer', '115', 1, NULL, 20, 53, '', '115_main.jpg', '115_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543689, 0, NULL, NULL, NULL, NULL),
(116, 'Pyle PLT-AB8 Subwoofer - PLTAB8', '116', 1, NULL, 21, 53, '', '116_main.jpg', '116_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542992, 0, NULL, NULL, NULL, NULL),
(117, 'Pyle PLSQ10D Red Label Square', '117', 1, NULL, 21, 53, '', '117_main.jpg', '117_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542495, 0, NULL, NULL, NULL, NULL),
(118, 'Pioneer TS-W251R Subwoofer', '118', 1, NULL, 20, 53, '', '118_main.jpg', '118_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543269, 0, NULL, NULL, NULL, NULL),
(119, 'Pioneer TSSW2541D Subwoofer', '119', 0, 1, 20, 53, '', '119_main.jpg', '119_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543316, 0, NULL, 2, NULL, NULL),
(120, 'Pioneer JD-1212S 12-disc CD', '120', 1, NULL, 20, 54, '', '120_main.jpg', '120_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542029, 0, NULL, NULL, NULL, NULL),
(121, 'Pioneer JD-612V 6-disc CD Magazine', '121', 1, NULL, 20, 54, '', '121_main.jpg', '121_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543909, 0, NULL, NULL, NULL, NULL),
(122, 'Panasonic CX-DP880U 8-Disc', '122', 1, NULL, 11, 54, '', '122_main.jpg', '122_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543511, 0, NULL, NULL, NULL, NULL),
(123, 'JVC - XCM200 - 12-Disc CD', '123', 1, NULL, 22, 54, '', '123_main.jpg', '123_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307543925, 0, NULL, NULL, NULL, NULL),
(124, 'JVC - CHX1500RF - FM Modulation', '124', 1, NULL, 22, 54, '', '124_main.jpg', '124_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542680, 0, NULL, NULL, NULL, NULL),
(125, 'Garmin Forerunner 305 Portable Navigator', '125', 1, 0, 23, 55, '', '125_main.jpg', '125_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542859, 0, NULL, NULL, NULL, NULL),
(126, 'Скидка 50% на выходные на Черном море (курорт Ильичевск, Одесская область)', '126', 1, NULL, 23, 55, '', '126_main.jpg', '126_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307545111, 1311074320, 75.00, 1, NULL, NULL),
(127, 'TomTom XXL 540 S Portable GPS System', '127', 1, 0, 24, 55, '', '127_main.jpg', '127_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307541663, 0, NULL, NULL, NULL, NULL),
(128, 'TOMTOM XL 350 Automobile', '128', 1, NULL, 0, 36, '', '128_main.jpg', '128_small.jpg', '', '', '', '', '', 1307543046, 0, NULL, NULL, NULL, NULL),
(129, 'TOMTOM XXL 550M Automobile Portable Navigator', '129', 1, 0, 24, 55, '', '129_main.jpg', '129_small.jpg', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '', 1307542398, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_products_rating`
--

CREATE TABLE IF NOT EXISTS `shop_products_rating` (
  `product_id` int(11) NOT NULL,
  `votes` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_products_rating`
--

INSERT INTO `shop_products_rating` (`product_id`, `votes`, `rating`) VALUES
(71, 1, 2),
(81, 1, 5),
(88, 1, 1),
(76, 2, 7),
(82, 1, 4),
(77, 1, 3),
(73, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_categories`
--

CREATE TABLE IF NOT EXISTS `shop_product_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`category_id`),
  KEY `shop_product_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_product_categories`
--

INSERT INTO `shop_product_categories` (`product_id`, `category_id`) VALUES
(71, 36),
(71, 37),
(72, 36),
(72, 37),
(73, 36),
(73, 37),
(74, 38),
(75, 38),
(76, 36),
(76, 37),
(77, 38),
(78, 38),
(79, 38),
(80, 38),
(81, 38),
(82, 36),
(83, 36),
(84, 36),
(85, 36),
(86, 36),
(87, 40),
(87, 41),
(88, 40),
(88, 41),
(89, 40),
(89, 41),
(90, 40),
(90, 41),
(91, 40),
(91, 41),
(92, 40),
(92, 43),
(93, 40),
(93, 43),
(94, 40),
(94, 43),
(95, 44),
(95, 45),
(96, 44),
(96, 45),
(97, 44),
(97, 45),
(98, 44),
(98, 45),
(99, 44),
(99, 45),
(100, 44),
(100, 46),
(101, 44),
(101, 46),
(102, 44),
(102, 46),
(103, 44),
(103, 46),
(104, 44),
(104, 46),
(105, 48),
(105, 50),
(106, 48),
(106, 50),
(107, 48),
(107, 50),
(108, 48),
(108, 50),
(109, 48),
(109, 50),
(110, 48),
(110, 51),
(111, 48),
(111, 51),
(112, 48),
(112, 51),
(113, 48),
(113, 51),
(114, 48),
(114, 51),
(115, 52),
(115, 53),
(116, 53),
(117, 52),
(117, 53),
(118, 52),
(118, 53),
(119, 48),
(119, 53),
(120, 54),
(121, 54),
(122, 54),
(123, 52),
(123, 54),
(124, 52),
(124, 54),
(125, 52),
(125, 55),
(126, 52),
(126, 55),
(127, 52),
(127, 55),
(128, 36),
(128, 52),
(129, 52),
(129, 55);

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_images`
--

CREATE TABLE IF NOT EXISTS `shop_product_images` (
  `product_id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`product_id`,`image_name`),
  KEY `shop_product_images_I_1` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_product_images`
--

INSERT INTO `shop_product_images` (`product_id`, `image_name`, `position`) VALUES
(71, '71_0.jpg', 0),
(71, '71_1.jpg', 1),
(71, '71_2.jpg', 2),
(72, '72_0.jpg', 0),
(72, '72_1.jpg', 1),
(72, '72_2.jpg', 2),
(74, '74_0.jpg', 0),
(74, '74_1.jpg', 1),
(74, '74_2.jpg', 2),
(76, '76_0.jpg', 0),
(76, '76_1.jpg', 1),
(76, '76_2.jpg', 2),
(81, '81_0.jpg', 0),
(81, '81_1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_properties`
--

CREATE TABLE IF NOT EXISTS `shop_product_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `csv_name` varchar(50) NOT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `show_in_compare` tinyint(4) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `data` text,
  `show_on_site` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_I_1` (`name`),
  KEY `shop_product_properties_I_2` (`active`),
  KEY `shop_product_properties_I_3` (`show_on_site`),
  KEY `shop_product_properties_I_4` (`show_in_compare`),
  KEY `shop_product_properties_I_5` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `shop_product_properties`
--

INSERT INTO `shop_product_properties` (`id`, `name`, `csv_name`, `active`, `show_in_compare`, `position`, `data`, `show_on_site`) VALUES
(20, 'Адрес', 'addres', 1, 0, 1, '', 1),
(21, 'Телефон', 'phone', 1, 1, 2, '', 1),
(29, 'Период действия акции', 'period', 1, NULL, 0, '', NULL),
(30, 'Первоначальная стоимость услуги', 'cost', 1, NULL, 0, '', NULL),
(22, 'Время', 'time', 1, 1, 3, '', 1),
(23, 'Сайт', 'website', 1, 1, 4, '', 1),
(28, 'Краткое название', 'shortdescr', 1, NULL, 0, '', NULL),
(24, 'Количество цифровых входов', 'digitalopticalinput', 1, 1, 5, 'a:4:{i:0;s:1:"2";i:1;s:1:"3";i:2;s:1:"4";i:3;s:1:"5";}', 1),
(25, 'Настройка фокуса', 'focus', 1, 1, 6, 'a:2:{i:0;s:28:"автоматическая";i:1;s:12:"ручная";}', 1),
(26, 'Количество мегапикселей', 'megapixel', 1, 1, 7, 'a:5:{i:0;s:1:"5";i:1;s:2:"10";i:2;s:2:"15";i:3;s:2:"20";i:4;s:2:"25";}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_properties_categories`
--

CREATE TABLE IF NOT EXISTS `shop_product_properties_categories` (
  `property_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`property_id`,`category_id`),
  KEY `shop_product_properties_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_product_properties_categories`
--

INSERT INTO `shop_product_properties_categories` (`property_id`, `category_id`) VALUES
(20, 36),
(20, 37),
(20, 38),
(20, 40),
(20, 41),
(20, 43),
(20, 44),
(20, 45),
(20, 46),
(20, 48),
(20, 50),
(20, 51),
(20, 52),
(20, 53),
(20, 54),
(20, 55),
(21, 36),
(21, 37),
(21, 38),
(21, 40),
(21, 41),
(21, 43),
(21, 44),
(21, 45),
(21, 46),
(21, 48),
(21, 50),
(21, 51),
(21, 52),
(21, 53),
(21, 54),
(21, 55),
(22, 36),
(22, 37),
(22, 38),
(22, 40),
(22, 41),
(22, 43),
(22, 44),
(22, 45),
(22, 46),
(22, 48),
(22, 50),
(22, 51),
(22, 52),
(22, 53),
(22, 54),
(22, 55),
(23, 36),
(23, 37),
(23, 38),
(23, 40),
(23, 41),
(23, 43),
(23, 44),
(23, 45),
(23, 46),
(23, 48),
(23, 50),
(23, 51),
(23, 52),
(23, 53),
(23, 54),
(23, 55),
(24, 41),
(25, 45),
(26, 45),
(28, 36),
(28, 37),
(28, 38),
(28, 40),
(28, 41),
(28, 43),
(28, 44),
(28, 45),
(28, 46),
(28, 48),
(28, 50),
(28, 51),
(28, 52),
(28, 53),
(28, 54),
(28, 55),
(29, 36),
(29, 37),
(29, 38),
(29, 40),
(29, 41),
(29, 43),
(29, 44),
(29, 45),
(29, 46),
(29, 48),
(29, 50),
(29, 51),
(29, 52),
(29, 53),
(29, 54),
(29, 55),
(30, 36),
(30, 37),
(30, 38),
(30, 40),
(30, 41),
(30, 43),
(30, 44),
(30, 45),
(30, 46),
(30, 48),
(30, 50),
(30, 51),
(30, 52),
(30, 53),
(30, 54),
(30, 55);

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_properties_data`
--

CREATE TABLE IF NOT EXISTS `shop_product_properties_data` (
  `property_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`property_id`,`product_id`),
  KEY `shop_product_properties_data_I_1` (`value`(333)),
  KEY `shop_product_properties_data_FI_2` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_product_properties_data`
--

INSERT INTO `shop_product_properties_data` (`property_id`, `product_id`, `value`) VALUES
(30, 72, '80000'),
(21, 72, '47'),
(21, 73, '42'),
(20, 73, 'Plasma'),
(21, 74, '40'),
(20, 74, 'LCD'),
(21, 75, '32'),
(20, 75, 'LED'),
(29, 76, 'Круглый год!'),
(22, 87, 'есть'),
(23, 87, '1 кВт'),
(24, 87, '2'),
(24, 88, '2'),
(23, 88, '2 кВт'),
(22, 88, 'нет'),
(24, 89, '3'),
(23, 89, '1 кВт'),
(22, 89, 'нет'),
(22, 90, 'есть'),
(23, 90, '3 кВт'),
(24, 90, '2'),
(24, 91, '2'),
(23, 91, '2 кВт'),
(22, 91, 'нет'),
(25, 95, 'автоматическая'),
(25, 96, 'ручная'),
(25, 97, 'ручная'),
(25, 98, 'автоматическая'),
(25, 99, 'ручная'),
(26, 97, '4'),
(26, 98, '4'),
(26, 96, '3'),
(26, 95, '3'),
(26, 99, '5'),
(30, 71, '20000'),
(29, 71, 'С 24 апреля и по 27 апреля'),
(28, 71, 'Rubin Plaza Game Zone'),
(23, 71, 'www.rubin-plaza.relax.by'),
(22, 71, 'пн. — вс.: с 12.00 до 00.00'),
(21, 71, '(8 029) 685-75-77'),
(29, 77, 'С 1 июля по 31 августа'),
(29, 92, 'С 24 апреля и по 20 июля'),
(20, 72, 'LED'),
(20, 71, 'пр-т Дзержинского, 5'),
(23, 76, 'http://minskonsight.com'),
(28, 76, 'Услуги автоцентра Маяк'),
(30, 76, '40000'),
(22, 76, 'пн. — вс.: с 12.00 до 00.00'),
(21, 76, '8 (017) 325-26-35'),
(20, 76, 'ул. Голубева 36');

-- --------------------------------------------------------

--
-- Table structure for table `shop_product_variants`
--

CREATE TABLE IF NOT EXISTS `shop_product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `price` float(10,2) NOT NULL,
  `number` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_variants_I_1` (`product_id`),
  KEY `shop_product_variants_I_2` (`position`),
  KEY `shop_product_variants_I_3` (`number`),
  KEY `shop_product_variants_I_4` (`name`(333)),
  KEY `shop_product_variants_I_5` (`price`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=192 ;

--
-- Dumping data for table `shop_product_variants`
--

INSERT INTO `shop_product_variants` (`id`, `product_id`, `name`, `price`, `number`, `stock`, `position`) VALUES
(1, 1, NULL, 99.99, NULL, NULL, NULL),
(2, 2, 'variant 1', 522.00, '', 0, 1),
(3, 3, 'red', 522.00, '', 0, 0),
(5, 2, 'variant 2', 590.00, '', 0, 0),
(6, 4, '', 10.00, '', 0, 0),
(7, 5, '', 5.00, '', 0, 0),
(8, 6, '', 36.00, '', 0, 0),
(9, 7, '', 6.10, '', 0, 0),
(10, 8, '', 6.23, '', 0, 0),
(11, 9, NULL, 9.00, NULL, NULL, NULL),
(12, 10, NULL, 5.00, NULL, NULL, NULL),
(13, 11, NULL, 18.00, NULL, NULL, NULL),
(14, 12, NULL, 20.00, NULL, NULL, NULL),
(15, 13, NULL, 10.00, NULL, NULL, NULL),
(16, 14, '', 19.00, '', 0, 0),
(17, 15, NULL, 15.00, NULL, NULL, NULL),
(18, 16, NULL, 19.00, NULL, NULL, NULL),
(19, 17, NULL, 17.00, NULL, NULL, NULL),
(20, 18, '', 100.00, '', 0, 0),
(21, 19, NULL, 51.00, NULL, NULL, NULL),
(22, 20, '', 29.00, '', 0, 0),
(23, 21, NULL, 35.00, NULL, NULL, NULL),
(24, 22, '', 36.00, '', 0, 0),
(25, 23, '', 32.00, '', 0, 0),
(26, 24, '', 25.00, '', 0, 0),
(27, 25, NULL, 39.00, NULL, NULL, NULL),
(28, 26, NULL, 79.00, NULL, NULL, NULL),
(29, 27, NULL, 41.00, NULL, NULL, NULL),
(30, 28, NULL, 57.00, NULL, NULL, NULL),
(31, 29, NULL, 70.00, NULL, NULL, NULL),
(32, 30, NULL, 59.00, NULL, NULL, NULL),
(33, 31, NULL, 10.00, NULL, NULL, NULL),
(34, 32, NULL, 19.00, NULL, NULL, NULL),
(37, 35, '', 99.00, '', 0, 0),
(38, 36, NULL, 10.00, NULL, NULL, NULL),
(39, 37, NULL, 10.00, NULL, NULL, NULL),
(40, 38, NULL, 20.00, NULL, NULL, NULL),
(41, 39, NULL, 22.00, NULL, NULL, NULL),
(42, 40, NULL, 30.00, NULL, NULL, NULL),
(43, 41, NULL, 55.00, NULL, NULL, NULL),
(44, 42, '', 17.00, '', 0, 3),
(45, 43, NULL, 45.00, NULL, NULL, NULL),
(46, 44, NULL, 100.00, NULL, NULL, NULL),
(47, 45, NULL, 8.00, NULL, NULL, NULL),
(48, 46, NULL, 17.00, NULL, NULL, NULL),
(49, 47, NULL, 22.00, NULL, NULL, NULL),
(50, 48, NULL, 16.00, NULL, NULL, NULL),
(51, 49, 'ghj', 60.00, NULL, NULL, 0),
(52, 50, '', 12.00, '', 0, 0),
(55, 53, NULL, 23.00, NULL, NULL, NULL),
(57, 55, NULL, 22.00, NULL, NULL, NULL),
(58, 56, NULL, 24.00, NULL, NULL, NULL),
(60, 58, NULL, 27.00, NULL, NULL, NULL),
(61, 59, '', 20.00, '', 0, 0),
(62, 60, NULL, 22.00, NULL, NULL, NULL),
(65, 63, NULL, 79.00, NULL, NULL, NULL),
(66, 64, NULL, 60.00, NULL, NULL, NULL),
(67, 65, NULL, 73.00, NULL, NULL, NULL),
(68, 66, NULL, 41.00, NULL, NULL, NULL),
(69, 67, NULL, 13.00, NULL, NULL, NULL),
(70, 68, NULL, 17.00, NULL, NULL, NULL),
(71, 69, NULL, 34.00, NULL, NULL, NULL),
(72, 49, '1212', 234.00, '', 0, 1),
(73, 70, '', 11.59, '', 0, 0),
(74, 41, '60W', 43.00, NULL, NULL, NULL),
(75, 41, '75W', 55.00, NULL, NULL, NULL),
(76, 42, 'Зеленая', 14.00, '', 0, 2),
(77, 42, 'Красная', 15.00, '', 0, 1),
(78, 42, 'Белая', 17.00, '', 0, 0),
(79, 57, 'Обычная упаковка', 245.99, NULL, NULL, 0),
(80, 57, 'Подарочная упаковка', 60.00, NULL, NULL, 2),
(81, 57, 'Пластиковая упаковка', 100.25, NULL, NULL, 1),
(82, 71, '', 1000.00, '0', 355, 0),
(83, 72, '', 5000.00, '', 0, 0),
(84, 73, '', 78000.00, 'TC-L42', 16, 0),
(85, 74, '', 90000.00, 'LN40C', 20, 0),
(86, 75, '', 450000.00, 'CLP-32', 250, 0),
(87, 76, 'Красный', 10000.00, 'CLP-32L', 50, 0),
(88, 77, '', 120000.00, '', 0, 0),
(89, 78, '', 150000.00, '', 30, 0),
(90, 79, '', 39.95, '', 100, 0),
(91, 80, '', 44.77, '', 0, 0),
(92, 81, '', 200000.00, '', 15, 0),
(93, 82, '', 80000.00, '', 20, 0),
(94, 83, '', 129.00, '', 0, 0),
(95, 84, '', 100.51, '', 0, 0),
(96, 85, '', 219.99, '', 0, 0),
(97, 86, '', 154.00, '', 0, 0),
(98, 87, '', 349.00, '', 0, 0),
(99, 88, '', 550.00, '', 10, 0),
(100, 89, '', 371.99, '', 0, 0),
(101, 90, '', 999.00, '', 0, 0),
(102, 91, '', 548.00, '', 0, 0),
(103, 92, '', 300.00, '', 10, 0),
(104, 93, '', 349.99, '', 0, 0),
(105, 94, '', 99.95, '', 0, 0),
(106, 95, '', 799.00, '', 0, 0),
(107, 96, '', 699.00, '', 0, 0),
(108, 97, '', 799.00, '', 0, 0),
(109, 98, '', 549.00, '', 0, 0),
(110, 99, '', 499.99, '', 0, 0),
(111, 100, '', 179.87, '', 0, 0),
(112, 101, '', 74.99, '', 0, 0),
(113, 102, '', 549.99, '', 100, 0),
(114, 103, '', 86.91, '', 0, 0),
(115, 104, '', 799.99, '', 0, 0),
(116, 105, '', 99.95, '', 0, 0),
(117, 106, '', 72.05, '', 0, 0),
(118, 107, '', 219.28, '', 0, 0),
(119, 108, '', 219.99, '', 0, 0),
(120, 109, '', 123.37, '', 0, 0),
(121, 110, '', 36.95, '', 0, 0),
(122, 111, '', 20.40, '', 0, 0),
(123, 112, '', 12.99, '', 0, 0),
(124, 113, '', 10.99, '', 0, 0),
(125, 114, '', 19.99, '', 0, 0),
(126, 115, '', 45.00, '', 0, 0),
(127, 116, '', 60.99, '', 0, 0),
(128, 117, '', 47.22, '', 0, 0),
(129, 118, '', 56.00, '', 0, 0),
(130, 119, '', 69.00, '', 0, 0),
(131, 120, '', 30.71, '', 0, 0),
(132, 121, '', 28.18, '', 0, 0),
(133, 122, '', 35.00, '', 0, 0),
(134, 123, '', 42.00, '', 0, 0),
(135, 124, '', 34.00, '', 0, 0),
(136, 125, '', 137.12, '', 0, 0),
(137, 126, '', 130.00, '', 50, 0),
(138, 127, '', 100.35, '', 0, 0),
(139, 128, '', 179.99, '', NULL, 0),
(140, 129, '', 119.99, '', 0, 0),
(150, 139, '', 158.99, '', 0, 0),
(151, 140, '', 158.99, '', 0, 0),
(152, 142, '', 158.99, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `shop_settings`
--

CREATE TABLE IF NOT EXISTS `shop_settings` (
  `name` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shop_settings`
--

INSERT INTO `shop_settings` (`name`, `value`) VALUES
('mainImageWidth', '520'),
('mainImageHeight', '339'),
('smallImageWidth', '302'),
('smallImageHeight', '176'),
('addImageWidth', '800'),
('addImageHeight', '600'),
('imagesQuality', '70'),
('systemTemplatePath', './templates/commerce/shop/default'),
('frontProductsPerPage', '14'),
('adminProductsPerPage', '24'),
('ordersMessageFormat', 'text'),
('ordersMessageText', 'Здравствуйте, %userName%.  \n\nМы благодарны Вам за то, что совершили заказ в нашем магазине "ImageCMS Shop" \nВы указали следующие контактные данные: \n\nEmail адрес: %userEmail% \nНомер телефона: %userPhone% \nАдрес доставки: %userDeliver%  \n\nМенеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.  \n\nТакже, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:  %orderLink%.  \n\nСпасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.  \n\nПри возникновении любых вопросов, обращайтесь за телефонами:  \n+7 (095) 222-33-22 +38 (098) 222-33-22'),
('ordersSendMessage', 'true'),
('ordersSenderEmail', 'noreply@demoshop.imagecm.net'),
('ordersSenderName', 'DemoShop ImageCms.net'),
('ordersMessageTheme', 'Данные для просмотра совершенной покупки'),
('2_LMI_SECRET_KEY', 'bank'),
('2_LMI_PAYEE_PURSE', 'bank'),
('1_LMI_SECRET_KEY', 'cur'),
('1_LMI_PAYEE_PURSE', 'cur'),
('2_OschadBankData', 'a:5:{s:8:"receiver";s:41:"ТЗОВ "Екзампл Магазин" ";s:4:"code";s:9:"123456789";s:7:"account";s:12:"123456789123";s:3:"mfo";s:6:"123456";s:8:"banknote";s:7:"грн.";}'),
('3_SberBankData', 'a:8:{s:12:"receiverName";s:45:"Наименование получателя";s:8:"bankName";s:29:"Банк получателя";s:11:"receiverInn";s:10:"1231231231";s:7:"account";s:20:"15412398123312341237";s:3:"BIK";s:9:"123123123";s:11:"cor_account";s:20:"12312312334012340123";s:8:"bankNote";s:7:"руб.";s:9:"bankNote2";s:7:"коп.";}'),
('4_RobokassaData', 'a:3:{s:5:"login";s:5:"login";s:9:"password1";s:9:"password1";s:9:"password2";s:9:"password2";}');

-- --------------------------------------------------------

--
-- Table structure for table `shop_user_profile`
--

CREATE TABLE IF NOT EXISTS `shop_user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shop_user_profile`
--

INSERT INTO `shop_user_profile` (`id`, `user_id`, `name`, `phone`, `address`) VALUES
(1, 1, 'Administrator', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_warehouse`
--

CREATE TABLE IF NOT EXISTS `shop_warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_I_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shop_warehouse`
--

INSERT INTO `shop_warehouse` (`id`, `name`, `address`, `phone`, `description`) VALUES
(1, 'warehouse 1', 'address', 'phone', ''),
(2, 'warehouse 2', 'address 2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `shop_warehouse_data`
--

CREATE TABLE IF NOT EXISTS `shop_warehouse_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_data_FI_1` (`product_id`),
  KEY `shop_warehouse_data_FI_2` (`warehouse_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `shop_warehouse_data`
--

INSERT INTO `shop_warehouse_data` (`id`, `product_id`, `warehouse_id`, `count`) VALUES
(37, 132, 2, 3),
(36, 132, 1, 2),
(35, 132, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `value` (`value`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '1',
  `username` varchar(25) NOT NULL,
  `password` varchar(34) NOT NULL,
  `email` varchar(100) NOT NULL,
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) DEFAULT NULL,
  `newpass` varchar(34) DEFAULT NULL,
  `newpass_key` varchar(32) DEFAULT NULL,
  `newpass_time` datetime DEFAULT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `about` text NOT NULL,
  `age` int(11) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `ava` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `hobbies` varchar(255) NOT NULL,
  `newsletter` smallint(1) NOT NULL,
  `notifications` smallint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  KEY `banned` (`banned`),
  KEY `password` (`password`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=114 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `status`, `about`, `age`, `phone`, `last_name`, `first_name`, `ava`, `city`, `sex`, `hobbies`, `newsletter`, `notifications`) VALUES
(84, 1, 'test', '$1$z95.AX3.$.aeeY2P/IAIcZhRBNeh3L.', 'test@test.ru', 0, NULL, NULL, NULL, NULL, '127.0.0.1', '2011-07-01 21:41:41', '2011-07-01 21:39:36', '2011-07-01 20:41:41', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(87, 1, 'vinilzen', '$1$LA4.2A4.$egUF4IUGbVH/ojCdkeigA.', 'marchukil@mail.ru', 0, '', NULL, NULL, NULL, '127.0.0.1', '2011-07-07 18:15:56', '2011-06-20 11:45:03', '2011-07-07 17:15:56', 'Курю бамбук', 'дуб', 23, '+375298741236', 'Шамахов', 'Вадим', '00045781.jpg', 'Москва', 'm', 'бег, бокс', 0, 0),
(110, 1, 'mi@nineseven.ru', '$1$5H1.of2.$qpAR56hwGr503sJovKVyA0', 'mi@nineseven.ru', 0, NULL, NULL, NULL, NULL, '127.0.0.1', '2011-07-04 12:49:28', '2011-07-04 12:49:17', '2011-07-04 11:49:28', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(109, 1, 'mi@yandex.ru', '$1$Ei3.7m..$zDMM4wruLZdfn4QWxWbzK0', 'mi@yandex.ru', 0, NULL, NULL, NULL, NULL, '127.0.0.1', '2011-07-04 11:21:07', '2011-07-04 11:20:49', '2011-07-04 10:21:07', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(111, 1, 'hor@tut.by', '$1$6M3.V42.$yElPWu1cepO79VmNqxg.M0', 'hor@tut.by', 0, NULL, NULL, NULL, NULL, '192.168.1.2', '2011-07-06 16:15:10', '2011-07-06 16:15:01', '2011-07-06 15:15:10', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(112, 1, 'dj_al_dd@tut.by', '$1$dc5.i41.$yAcolt9CT1kIMZQcLBZ84.', 'dj_al_dd@tut.by', 0, NULL, NULL, NULL, NULL, '192.168.1.3', '0000-00-00 00:00:00', '2011-07-06 16:39:20', '2011-07-06 15:39:20', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(113, 1, 'dj_al_dd@mail.by', '$1$720.Cw5.$oOl/A2xovUTxZVr5o0T9Y0', 'dj_al_dd@mail.by', 0, NULL, NULL, NULL, NULL, '192.168.1.3', '2011-07-06 16:40:34', '2011-07-06 16:40:15', '2011-07-06 15:40:34', '', '', 0, '', '', '', '', '', '', '', 0, 0),
(1, 2, 'admin', '$1$lJ..Kx4.$I4OwnawPxNGu97KR4NqQx1', 'marchukilya@gmail.com', 0, NULL, NULL, NULL, NULL, '127.0.0.1', '2011-07-25 11:32:32', '2011-07-11 11:24:53', '2011-07-25 10:32:32', '0', '0', 553809600, '+375298710221', 'Король', 'Вася', '', '0', 'm', '0', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE IF NOT EXISTS `user_autologin` (
  `key_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`),
  KEY `last_ip` (`last_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('dcad79170f2eeaeed6032bbc8669ccf2', 88, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30', '127.0.0.1', '2011-07-22 19:04:27'),
('e3f2ea1e0a216707d65847f88a0d91f7', 1, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0', '127.0.0.1', '2011-07-23 10:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_id`) VALUES
(1, 84),
(2, 85),
(3, 86),
(4, 87),
(5, 88);

-- --------------------------------------------------------

--
-- Table structure for table `user_temp`
--

CREATE TABLE IF NOT EXISTS `user_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(34) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_key` varchar(50) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user_temp`
--


-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `data` text NOT NULL,
  `method` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  `description` varchar(300) NOT NULL,
  `roles` text NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES
(3, 'latest_news', 'module', 'core', 'recent_news', 'a:4:{s:10:"news_count";s:1:"3";s:11:"max_symdols";s:3:"150";s:10:"categories";a:1:{i:0;s:2:"56";}s:7:"display";s:6:"recent";}', 'Последние новости', '', 1291632457),
(4, 'recent_product_comments', 'module', 'comments', 'recent_product_comments', 'a:2:{s:14:"comments_count";i:100;s:13:"symbols_count";i:0;}', '', '', 1308300371);
